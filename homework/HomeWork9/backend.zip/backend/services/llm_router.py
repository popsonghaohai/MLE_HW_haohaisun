"""
LLM Router with Function Calling for tool orchestration.
Supports both OpenAI GPT models and local models via Ollama.
"""
import logging
import json
from typing import Optional, List, Dict, Any, Callable, AsyncGenerator, Union
from dataclasses import dataclass, field
from datetime import datetime
import httpx
import re

logger = logging.getLogger(__name__)


# Try to import OpenAI (optional if using local LLM)
try:
    from openai import AsyncOpenAI
    OPENAI_AVAILABLE = True
except ImportError:
    OPENAI_AVAILABLE = False


@dataclass
class Message:
    """Chat message with role and content."""
    role: str  # system, user, assistant, tool
    content: str
    tool_calls: Optional[List[Dict]] = None
    tool_call_id: Optional[str] = None
    timestamp: datetime = field(default_factory=datetime.utcnow)

    def to_dict(self) -> Dict:
        """Convert to dictionary format."""
        msg = {"role": self.role, "content": self.content}
        if self.tool_calls:
            msg["tool_calls"] = self.tool_calls
        if self.tool_call_id:
            msg["tool_call_id"] = self.tool_call_id
        return msg


@dataclass
class ToolDefinition:
    """Definition of a callable tool for function calling."""
    name: str
    description: str
    parameters: Dict[str, Any]
    function: Callable
    async_function: Optional[Callable] = None

    def to_dict(self) -> Dict:
        """Convert to function format."""
        return {
            "type": "function",
            "function": {
                "name": self.name,
                "description": self.description,
                "parameters": self.parameters
            }
        }


@dataclass
class ToolResult:
    """Result from a tool execution."""
    tool_name: str
    result: Any
    success: bool
    error: Optional[str] = None
    metadata: Dict = field(default_factory=dict)

    def to_message_content(self) -> str:
        """Convert to message content for LLM."""
        if self.success:
            if isinstance(self.result, str):
                return self.result
            elif isinstance(self.result, dict):
                return json.dumps(self.result, ensure_ascii=False)
            elif isinstance(self.result, list):
                return json.dumps(self.result, ensure_ascii=False)
            else:
                return str(self.result)
        else:
            return f"Error: {self.error}"


class OllamaClient:
    """Simple async client for Ollama local LLM."""

    def __init__(self, base_url: str = "http://localhost:11434", model: str = "qwen3:8b"):
        self.base_url = base_url
        self.model = model
        self.client = httpx.AsyncClient(timeout=120.0)

    async def chat(
        self,
        messages: List[Dict],
        tools: Optional[List[Dict]] = None,
        temperature: float = 0.7,
        stream: bool = False
    ) -> Union[str, AsyncGenerator[str, None]]:
        """Send chat request to Ollama."""
        # Build prompt from messages
        prompt = self._messages_to_prompt(messages, tools)

        payload = {
            "model": self.model,
            "prompt": prompt,
            "stream": stream,
            "options": {
                "temperature": temperature,
                "num_predict": 2000
            }
        }

        if stream:
            return self._stream_response(payload)
        else:
            response = await self.client.post(f"{self.base_url}/api/generate", json=payload)
            response.raise_for_status()
            data = response.json()
            return data.get("response", "")

    def _messages_to_prompt(self, messages: List[Dict], tools: Optional[List[Dict]] = None) -> str:
        """Convert messages to prompt string for Ollama."""
        prompt_parts = []

        # Add system prompt with tools info
        system_msg = next((m for m in messages if m["role"] == "system"), None)
        if system_msg:
            prompt_parts.append(f"System: {system_msg['content']}\n")

        # Add tools description with explicit examples
        if tools:
            prompt_parts.append("\n=== AVAILABLE TOOLS ===\n")
            for tool in tools:
                params = tool['function'].get('parameters', {}).get('properties', {})
                prompt_parts.append(f"\nTool: {tool['function']['name']}\n")
                prompt_parts.append(f"Description: {tool['function']['description']}\n")
                if params:
                    prompt_parts.append(f"Parameters: {', '.join(params.keys())}\n")

            prompt_parts.append("\n=== TOOL USAGE INSTRUCTIONS ===\n")
            prompt_parts.append("IMPORTANT: When the user asks for papers, research, or academic content, you MUST use the appropriate tool!\n")
            prompt_parts.append("\nTo use a tool, respond EXACTLY in this format:\n")
            prompt_parts.append("USE_TOOL: tool_name|param1=value1|param2=value2\n\n")
            prompt_parts.append("Examples:\n")
            prompt_parts.append("- User: 'Search for papers about machine learning'\n")
            prompt_parts.append("  Assistant: USE_TOOL: search_arxiv|query=machine learning|max_results=5\n")
            prompt_parts.append("- User: 'What are recent papers on quantum computing?'\n")
            prompt_parts.append("  Assistant: USE_TOOL: search_arxiv|query=quantum computing|max_results=5\n")
            prompt_parts.append("- User: 'Search the web for AI research'\n")
            prompt_parts.append("  Assistant: USE_TOOL: search_web|query=AI research|max_results=5\n\n")
            prompt_parts.append("After using USE_TOOL, wait for the system to provide results and then respond to the user.\n\n")

        # Add conversation history
        for msg in messages:
            if msg["role"] == "user":
                prompt_parts.append(f"User: {msg['content']}\n")
            elif msg["role"] == "assistant" and msg.get("content"):
                # Skip tool call messages in history to avoid confusion
                if not msg.get("content", "").startswith("[Used tool:"):
                    prompt_parts.append(f"Assistant: {msg['content']}\n")

        prompt_parts.append("Assistant:")
        return "".join(prompt_parts)

    async def _stream_response(self, payload: Dict) -> AsyncGenerator[str, None]:
        """Stream response from Ollama."""
        async with self.client.stream("POST", f"{self.base_url}/api/generate", json=payload) as response:
            response.raise_for_status()
            async for line in response.aiter_lines():
                if line.strip():
                    data = json.loads(line)
                    if "response" in data:
                        yield data["response"]

    async def close(self):
        """Close the client."""
        await self.client.aclose()


class LLMRouter:
    """
    LLM-based router for tool orchestration.
    Supports OpenAI GPT models and local models via Ollama.
    """

    # Default system prompt
    DEFAULT_SYSTEM_PROMPT = """You are an Academic Research Assistant, an AI that helps users search, understand, and summarize academic content. Your capabilities include:

1. **ArXiv Search**: Search academic papers on arXiv across various fields (CS, Math, Physics, etc.)
2. **Web Search**: Search the web for academic information, university resources, and research
3. **Context Retrieval**: Access our knowledge base of previously indexed research papers
4. **Summarization**: Synthesize and summarize multiple papers or research findings

When a user asks a question:
- For academic paper searches, use search_arxiv with a clear query
- For general academic queries, use search_web
- When you find papers, provide brief summaries and links

Always provide:
- Clear, direct answers
- Proper citations (paper titles, authors, years)
- Links to sources when available
- Follow-up suggestions for deeper exploration

Be concise but thorough. Focus on accuracy and helpfulness."""

    def __init__(
        self,
        use_local_llm: bool = True,
        local_llm_base_url: str = "http://localhost:11434",
        local_llm_model: str = "qwen3:8b",
        api_key: Optional[str] = None,
        model: Optional[str] = None,
        system_prompt: Optional[str] = None,
        temperature: float = 0.7
    ):
        """
        Initialize the LLM router.

        Args:
            use_local_llm: Use Ollama local LLM instead of OpenAI
            local_llm_base_url: Ollama server URL
            local_llm_model: Model name in Ollama
            api_key: OpenAI API key (if not using local)
            model: OpenAI model name
            system_prompt: Custom system prompt
            temperature: Sampling temperature
        """
        self.use_local_llm = use_local_llm
        self.temperature = temperature
        self.system_prompt = system_prompt or self.DEFAULT_SYSTEM_PROMPT
        self.tools: Dict[str, ToolDefinition] = {}
        self.conversation_history: List[Message] = []

        if use_local_llm:
            self.ollama_client = OllamaClient(local_llm_base_url, local_llm_model)
            self.openai_client = None
            logger.info(f"LLM Router initialized with local model: {local_llm_model}")
        else:
            if not OPENAI_AVAILABLE:
                raise ImportError("OpenAI package not installed")
            if not api_key:
                raise ValueError("OpenAI API key required when not using local LLM")
            self.openai_client = AsyncOpenAI(api_key=api_key)
            self.ollama_client = None
            self.model = model or "gpt-4o"
            logger.info(f"LLM Router initialized with OpenAI model: {self.model}")

    def register_tool(self, tool: ToolDefinition):
        """Register a tool for function calling."""
        self.tools[tool.name] = tool
        logger.debug(f"Registered tool: {tool.name}")

    def register_tools(self, tools: List[ToolDefinition]):
        """Register multiple tools."""
        for tool in tools:
            self.register_tool(tool)

    def reset_conversation(self):
        """Clear conversation history."""
        self.conversation_history = []
        logger.debug("Conversation history cleared")

    def add_to_history(self, message: Message):
        """Add a message to conversation history."""
        self.conversation_history.append(message)

        # Keep only recent messages
        max_history = 50
        if len(self.conversation_history) > max_history:
            self.conversation_history = self.conversation_history[-max_history:]

    async def chat(
        self,
        user_message: str,
        tools_to_use: Optional[List[str]] = None,
        original_message: Optional[str] = None
    ) -> AsyncGenerator[str, None]:
        """
        Process a user message through the LLM with tool calling.

        Args:
            user_message: The user's input message
            tools_to_use: Optional list of specific tools to use

        Yields:
            Response text chunks
        """
        # Use original_message for tool detection if provided, otherwise use user_message
        message_for_detection = original_message if original_message else user_message

        # Add user message to history
        user_msg = Message(role="user", content=user_message)
        self.add_to_history(user_msg)

        # Get available tools
        available_tools = self._get_available_tools(tools_to_use)

        # Build messages
        messages = self._build_messages()

        if self.use_local_llm:
            # Use Ollama (simpler tool handling)
            response_text = await self._chat_with_ollama(messages, available_tools, message_for_detection)
            self.add_to_history(Message(role="assistant", content=response_text))
            yield response_text
        else:
            # Use OpenAI with full function calling
            async for chunk in self._chat_with_openai(messages, available_tools):
                yield chunk

    async def _chat_with_ollama(
        self,
        messages: List[Dict],
        tools: List[Dict],
        message_for_detection: str
    ) -> str:
        """Chat using Ollama with simple tool pattern matching."""
        # Use the provided message_for_detection for keyword detection
        last_user_msg = message_for_detection.lower()
        last_user_msg_original = message_for_detection

        # Check for keywords that indicate tool usage
        tool_to_use = None
        tool_args = {}

        # ArXiv search keywords
        arxiv_keywords = ["arxiv", "papers", "research", "academic", "search for", "find papers"]
        if any(kw in last_user_msg for kw in arxiv_keywords):
            # Remove common phrases to extract the query
            query = last_user_msg_original
            for phrase in ["search arxiv for", "search for papers about", "find papers on", "search for", "arxiv:", "arxiv"]:
                query = query.replace(phrase, "", 1).strip()
                query = query.replace(phrase.capitalize(), "", 1).strip()

            if query and len(query) > 2:
                tool_to_use = "search_arxiv"
                tool_args = {"query": query, "max_results": 5}
                logger.info(f"Keyword detection triggered tool: {tool_to_use} with query: {query}")

        # Web search keywords
        web_keywords = ["web search", "search the web", "search online"]
        if any(kw in last_user_msg for kw in web_keywords) and not tool_to_use:
            query = last_user_msg_original
            for phrase in ["web search for", "search the web for", "search online for"]:
                query = query.replace(phrase, "", 1).strip()
                query = query.replace(phrase.capitalize(), "", 1).strip()

            if query and len(query) > 2:
                tool_to_use = "search_web"
                tool_args = {"query": query, "max_results": 5}
                logger.info(f"Keyword detection triggered tool: {tool_to_use} with query: {query}")

        # Execute tool if triggered
        if tool_to_use and tool_to_use in self.tools:
            tool = self.tools[tool_to_use]
            try:
                if tool.async_function:
                    result = await tool.async_function(**tool_args)
                else:
                    result = tool.function(**tool_args)

                # Add tool result to conversation and get final response
                tool_result_text = f"\n\nTool result for {tool_to_use}:\n{result}\n\nPlease provide a helpful response based on these results. Summarize the findings and provide relevant details."

                messages.append(Message(role="user", content=tool_result_text).to_dict())
                final_response = await self.ollama_client.chat(messages, temperature=self.temperature)

                # Store both the tool call and final response
                self.add_to_history(Message(role="assistant", content=f"[Used tool: {tool_to_use}]"))
                self.add_to_history(Message(role="assistant", content=final_response))

                return final_response

            except Exception as e:
                logger.error(f"Tool execution error: {e}")
                return f"I encountered an error using the {tool_to_use} tool: {str(e)}. Please try again or rephrase your request."

        # No tool triggered by keywords, check LLM response for USE_TOOL pattern
        response = await self.ollama_client.chat(
            messages=messages,
            tools=tools,
            temperature=self.temperature
        )

        # Check if response contains a tool call pattern
        tool_pattern = r"USE_TOOL:\s*(\w+)\|?(.*)"
        match = re.search(tool_pattern, response, re.IGNORECASE)

        if match:
            tool_name = match.group(1).strip()
            args_str = match.group(2).strip() if match.group(2) else ""

            # Parse arguments
            args = {}
            if args_str:
                for arg_pair in args_str.split("|"):
                    if "=" in arg_pair:
                        key, value = arg_pair.split("=", 1)
                        args[key.strip()] = value.strip()

            # Execute tool
            if tool_name in self.tools:
                tool = self.tools[tool_name]
                try:
                    if tool.async_function:
                        result = await tool.async_function(**args)
                    else:
                        result = tool.function(**args)

                    # Add tool result to conversation and get final response
                    tool_result_text = f"\n\nTool result for {tool_name}:\n{result}\n\nPlease provide a helpful response based on these results."

                    messages.append(Message(role="user", content=tool_result_text).to_dict())
                    final_response = await self.ollama_client.chat(messages, temperature=self.temperature)

                    # Store both the tool call and final response
                    self.add_to_history(Message(role="assistant", content=f"[Used tool: {tool_name}]"))
                    self.add_to_history(Message(role="assistant", content=final_response))

                    return final_response

                except Exception as e:
                    logger.error(f"Tool execution error: {e}")
                    return f"I encountered an error using the {tool_name} tool: {str(e)}. Please try again or rephrase your request."

        # No tool call, return response as-is
        # Remove any USE_TOOL pattern from response
        response_clean = re.sub(tool_pattern, "", response, flags=re.IGNORECASE).strip()
        return response_clean

    async def _chat_with_openai(
        self,
        messages: List[Dict],
        tools: List[Dict]
    ) -> AsyncGenerator[str, None]:
        """Chat using OpenAI with full function calling."""
        response = await self.openai_client.chat.completions.create(
            model=self.model,
            messages=messages,
            tools=tools if tools else None,
            tool_choice="auto" if tools else None,
            temperature=self.temperature,
            max_tokens=2000,
            stream=False
        )

        assistant_message = response.choices[0].message

        # Check for tool calls
        if assistant_message.tool_calls:
            assistant_msg = Message(
                role="assistant",
                content=assistant_message.content or "",
                tool_calls=[
                    {
                        "id": tc.id,
                        "type": tc.type,
                        "function": {
                            "name": tc.function.name,
                            "arguments": tc.function.arguments
                        }
                    }
                    for tc in assistant_message.tool_calls
                ]
            )
            self.add_to_history(assistant_msg)

            # Execute tools
            tool_results = []
            for tool_call in assistant_message.tool_calls:
                result = await self._execute_tool_call(tool_call)
                tool_results.append(result)
                self.add_to_history(Message(
                    role="tool",
                    content=result.to_message_content(),
                    tool_call_id=tool_call.id
                ))

            # Get final response
            final_messages = self._build_messages()
            final_response = await self.openai_client.chat.completions.create(
                model=self.model,
                messages=final_messages,
                temperature=self.temperature,
                max_tokens=2000
            )

            final_content = final_response.choices[0].message.content or ""
            self.add_to_history(Message(role="assistant", content=final_content))
            yield final_content
        else:
            content = assistant_message.content or ""
            self.add_to_history(Message(role="assistant", content=content))
            yield content

    async def _execute_tool_call(self, tool_call) -> ToolResult:
        """Execute a single tool call (OpenAI format)."""
        function_name = tool_call.function.name
        function_args = json.loads(tool_call.function.arguments)

        logger.info(f"Executing tool: {function_name} with args: {function_args}")

        if function_name not in self.tools:
            return ToolResult(
                tool_name=function_name,
                result=None,
                success=False,
                error=f"Unknown tool: {function_name}"
            )

        tool = self.tools[function_name]

        try:
            if tool.async_function:
                result = await tool.async_function(**function_args)
            else:
                result = tool.function(**function_args)

            return ToolResult(
                tool_name=function_name,
                result=result,
                success=True
            )
        except Exception as e:
            logger.error(f"Error executing {function_name}: {e}")
            return ToolResult(
                tool_name=function_name,
                result=None,
                success=False,
                error=str(e)
            )

    def _get_available_tools(self, tools_to_use: Optional[List[str]] = None) -> List[Dict]:
        """Get list of available tools."""
        if tools_to_use is None:
            tools_to_use = list(self.tools.keys())

        return [
            self.tools[name].to_dict()
            for name in tools_to_use
            if name in self.tools
        ]

    def _build_messages(self) -> List[Dict]:
        """Build messages list for API call."""
        messages = [{"role": "system", "content": self.system_prompt}]
        messages.extend([msg.to_dict() for msg in self.conversation_history])
        return messages

    async def close(self):
        """Clean up resources."""
        if self.ollama_client:
            await self.ollama_client.close()


# Global LLM router instance
_llm_router: Optional[LLMRouter] = None


def get_llm_router() -> LLMRouter:
    """Get or create the global LLM router instance."""
    global _llm_router
    if _llm_router is None:
        from backend.core.config import settings
        _llm_router = LLMRouter(
            use_local_llm=settings.USE_LOCAL_LLM,
            local_llm_base_url=settings.LOCAL_LLM_BASE_URL,
            local_llm_model=settings.LOCAL_LLM_MODEL,
            api_key=settings.OPENAI_API_KEY if not settings.USE_LOCAL_LLM else None,
            model=settings.OPENAI_MODEL if not settings.USE_LOCAL_LLM else None
        )
    return _llm_router


def create_tool_definition(
    name: str,
    description: str,
    parameters: Dict,
    async_function: Optional[Callable] = None,
    function: Optional[Callable] = None
) -> ToolDefinition:
    """Helper to create a ToolDefinition."""
    # Provide a dummy sync function if only async is provided
    if function is None and async_function is not None:
        def dummy_sync(**kwargs):
            raise NotImplementedError("Use async_function instead")
        function = dummy_sync

    return ToolDefinition(
        name=name,
        description=description,
        parameters=parameters,
        function=function or (lambda **kwargs: None),
        async_function=async_function
    )

"""
Vector Store Service using ChromaDB for semantic search and context retrieval.
"""
import logging
from typing import Optional, List, Dict, Any
from pathlib import Path
from datetime import datetime

logger = logging.getLogger(__name__)

try:
    import chromadb
    from chromadb.config import Settings as ChromaSettings
    CHROMADB_AVAILABLE = True
    logger.info(f"ChromaDB imported successfully, version: {chromadb.__version__}")
except ImportError as e:
    CHROMADB_AVAILABLE = False
    logger.error(f"Failed to import chromadb: {e}")

try:
    from sentence_transformers import SentenceTransformer
    SENTENCE_TRANSFORMERS_AVAILABLE = True
except ImportError:
    SENTENCE_TRANSFORMERS_AVAILABLE = False


class VectorStore:
    """
    Vector database service using ChromaDB for semantic search.
    Stores and retrieves document embeddings for context-aware responses.
    """

    def __init__(
        self,
        persist_directory: str,
        collection_name: str = "research_papers",
        embedding_model: str = "sentence-transformers/all-MiniLM-L6-v2"
    ):
        """
        Initialize the vector store.

        Args:
            persist_directory: Directory to persist the database
            collection_name: Name of the collection
            embedding_model: Name of the embedding model
        """
        if not CHROMADB_AVAILABLE:
            raise ImportError("chromadb is not installed. Install with: pip install chromadb")

        self.persist_directory = Path(persist_directory)
        self.persist_directory.mkdir(parents=True, exist_ok=True)
        self.collection_name = collection_name
        self.embedding_model_name = embedding_model

        # Initialize ChromaDB client
        self.client = chromadb.PersistentClient(
            path=str(self.persist_directory),
            settings=ChromaSettings(
                anonymized_telemetry=False,
                allow_reset=True
            )
        )

        # Get or create collection
        self.collection = self.client.get_or_create_collection(
            name=self.collection_name,
            metadata={"description": "Research papers and academic content"}
        )

        # Initialize embedding model
        self.embedding_model = None
        if SENTENCE_TRANSFORMERS_AVAILABLE:
            try:
                self.embedding_model = SentenceTransformer(embedding_model)
                logger.info(f"Loaded embedding model: {embedding_model}")
            except Exception as e:
                logger.warning(f"Failed to load embedding model: {e}")

        logger.info(f"Vector store initialized: {self.collection_name} at {self.persist_directory}")

    def _get_embeddings(self, texts: List[str]) -> List[List[float]]:
        """Generate embeddings for texts."""
        if self.embedding_model is not None:
            embeddings = self.embedding_model.encode(texts, convert_to_numpy=True)
            return embeddings.tolist()
        else:
            # Fallback: use ChromaDB's default embedding function
            return None

    def add_documents(
        self,
        documents: List[str],
        metadatas: Optional[List[Dict]] = None,
        ids: Optional[List[str]] = None
    ) -> bool:
        """
        Add documents to the vector store.

        Args:
            documents: List of document texts
            metadatas: Optional list of metadata dicts
            ids: Optional list of unique IDs

        Returns:
            True if successful
        """
        try:
            if not documents:
                return False

            # Generate IDs if not provided
            if ids is None:
                timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
                ids = [f"doc_{timestamp}_{i}" for i in range(len(documents))]

            # Generate embeddings
            embeddings = self._get_embeddings(documents)

            # Add to collection
            self.collection.add(
                documents=documents,
                metadatas=metadatas,
                ids=ids,
                embeddings=embeddings
            )

            logger.info(f"Added {len(documents)} documents to vector store")
            return True

        except Exception as e:
            logger.error(f"Error adding documents: {e}")
            return False

    def add_paper_chunks(
        self,
        paper_data: Dict[str, Any],
        chunk_size: int = 500,
        chunk_overlap: int = 50
    ) -> int:
        """
        Add a paper's text as chunks to the vector store.

        Args:
            paper_data: Paper dict with title, abstract, full_text, etc.
            chunk_size: Size of each chunk
            chunk_overlap: Overlap between chunks

        Returns:
            Number of chunks added
        """
        try:
            # Get text from paper
            text = paper_data.get("full_text") or paper_data.get("abstract", "")
            if not text:
                logger.warning(f"No text to add for paper: {paper_data.get('title', 'Unknown')}")
                return 0

            # Split into chunks
            chunks = self._chunk_text(text, chunk_size, chunk_overlap)

            # Prepare metadata for each chunk
            arxiv_id = paper_data.get("arxiv_id", paper_data.get("id", ""))
            base_metadata = {
                "title": paper_data.get("title", ""),
                "arxiv_id": arxiv_id,
                "authors": ", ".join(paper_data.get("authors", [])),
                "url": paper_data.get("url", ""),
                "pdf_url": paper_data.get("pdf_url", ""),
                "year": paper_data.get("published", "")[:4] if paper_data.get("published") else "",
                "category": paper_data.get("primary_category", ""),
            }

            documents = []
            metadatas = []
            ids = []

            for i, chunk in enumerate(chunks):
                documents.append(chunk)
                chunk_metadata = base_metadata.copy()
                chunk_metadata["chunk_index"] = i
                chunk_metadata["total_chunks"] = len(chunks)
                metadatas.append(chunk_metadata)
                ids.append(f"{arxiv_id}_chunk_{i}")

            # Add to collection
            self.add_documents(documents, metadatas, ids)

            return len(chunks)

        except Exception as e:
            logger.error(f"Error adding paper chunks: {e}")
            return 0

    def _chunk_text(self, text: str, chunk_size: int, overlap: int) -> List[str]:
        """Split text into overlapping chunks."""
        # Simple word-based chunking
        words = text.split()
        chunks = []

        for i in range(0, len(words), chunk_size - overlap):
            chunk = " ".join(words[i:i + chunk_size])
            if chunk:
                chunks.append(chunk)

        return chunks

    def search(
        self,
        query: str,
        n_results: int = 5,
        filter_metadata: Optional[Dict] = None
    ) -> List[Dict[str, Any]]:
        """
        Search for similar documents.

        Args:
            query: Search query
            n_results: Number of results to return
            filter_metadata: Optional metadata filter

        Returns:
            List of results with document, metadata, and distance
        """
        try:
            # Generate query embedding
            query_embedding = None
            if self.embedding_model is not None:
                query_embedding = self.embedding_model.encode([query])[0].tolist()

            # Search
            results = self.collection.query(
                query_embeddings=[query_embedding] if query_embedding else None,
                query_texts=[query] if query_embedding is None else None,
                n_results=n_results,
                where=filter_metadata
            )

            # Format results
            formatted_results = []
            if results and results.get('documents'):
                for i, doc in enumerate(results['documents'][0]):
                    result = {
                        "text": doc,
                        "metadata": results['metadatas'][0][i] if results.get('metadatas') else {},
                        "distance": results['distances'][0][i] if results.get('distances') else None,
                        "id": results['ids'][0][i] if results.get('ids') else None
                    }
                    formatted_results.append(result)

            logger.info(f"Found {len(formatted_results)} results for query: {query[:50]}...")
            return formatted_results

        except Exception as e:
            logger.error(f"Error searching vector store: {e}")
            return []

    def get_context_for_query(
        self,
        query: str,
        n_results: int = 5,
        max_tokens: int = 2000
    ) -> str:
        """
        Get formatted context from search results.

        Args:
            query: Search query
            n_results: Number of results
            max_tokens: Maximum tokens in context

        Returns:
            Formatted context string
        """
        results = self.search(query, n_results)

        if not results:
            return "No relevant context found in the knowledge base."

        context_parts = []
        total_chars = 0
        char_limit = max_tokens * 4  # Rough estimate

        for i, result in enumerate(results, 1):
            metadata = result.get("metadata", {})
            text = result.get("text", "")

            context_part = f"""
[Source {i}]
Title: {metadata.get('title', 'Unknown')}
Authors: {metadata.get('authors', 'Unknown')}
ArXiv ID: {metadata.get('arxiv_id', 'N/A')}

{text}
"""
            if total_chars + len(context_part) > char_limit:
                break

            context_parts.append(context_part)
            total_chars += len(context_part)

        return "\n".join(context_parts)

    def delete_paper(self, arxiv_id: str) -> bool:
        """Delete all chunks for a paper."""
        try:
            # Get all IDs for this paper
            results = self.collection.get(
                where={"arxiv_id": arxiv_id}
            )

            if results and results.get('ids'):
                self.collection.delete(ids=results['ids'])
                logger.info(f"Deleted {len(results['ids'])} chunks for paper {arxiv_id}")
                return True

            return False

        except Exception as e:
            logger.error(f"Error deleting paper: {e}")
            return False

    def clear_collection(self) -> bool:
        """Clear all documents from the collection."""
        try:
            self.client.delete_collection(self.collection_name)
            self.collection = self.client.create_collection(
                name=self.collection_name,
                metadata={"description": "Research papers and academic content"}
            )
            logger.info(f"Cleared collection: {self.collection_name}")
            return True
        except Exception as e:
            logger.error(f"Error clearing collection: {e}")
            return False

    def get_stats(self) -> Dict[str, Any]:
        """Get statistics about the vector store."""
        try:
            count = self.collection.count()
            return {
                "collection_name": self.collection_name,
                "document_count": count,
                "persist_directory": str(self.persist_directory)
            }
        except Exception as e:
            logger.error(f"Error getting stats: {e}")
            return {}


# Global vector store instance
_vector_store: Optional[VectorStore] = None


def get_vector_store() -> VectorStore:
    """Get or create the global vector store instance."""
    global _vector_store
    if _vector_store is None:
        from backend.core.config import settings
        _vector_store = VectorStore(
            persist_directory=settings.CHROMA_PERSIST_DIR,
            embedding_model=settings.EMBEDDING_MODEL
        )
    return _vector_store


async def index_rag_data(rag_data_path: str) -> int:
    """
    Index RAG data from JSON file into vector store.

    Args:
        rag_data_path: Path to RAG JSON data file

    Returns:
        Number of papers indexed
    """
    import json

    vector_store = get_vector_store()

    with open(rag_data_path, 'r', encoding='utf-8') as f:
        papers = json.load(f)

    indexed_count = 0
    for paper in papers:
        chunks_added = vector_store.add_paper_chunks(paper)
        if chunks_added > 0:
            indexed_count += 1

    logger.info(f"Indexed {indexed_count} papers from {rag_data_path}")
    return indexed_count

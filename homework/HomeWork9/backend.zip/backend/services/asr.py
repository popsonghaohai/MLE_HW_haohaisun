"""
Automatic Speech Recognition (ASR) Service using local Whisper.
Supports multiple audio formats and model sizes.
"""
import os
import logging
import tempfile
from pathlib import Path
from typing import Optional, Union
import torch
import numpy as np

logger = logging.getLogger(__name__)

try:
    from faster_whisper import WhisperModel
    FASTER_WHISPER_AVAILABLE = True
except ImportError:
    FASTER_WHISPER_AVAILABLE = False

try:
    import whisper
    OPENAI_WHISPER_AVAILABLE = True
except ImportError:
    OPENAI_WHISPER_AVAILABLE = False


class ASRService:
    """
    Speech-to-text service using Whisper models.
    Supports both faster-whisper (recommended) and openai-whisper.
    """

    def __init__(
        self,
        model_size: str = "base",
        device: str = "cpu",
        use_faster: bool = True,
        compute_type: str = "int8"
    ):
        """
        Initialize the ASR service.

        Args:
            model_size: Whisper model size (tiny, base, small, medium, large)
            device: Device to run on (cpu, cuda)
            use_faster: Use faster-whisper if available (recommended)
            compute_type: Compute type for faster-whisper (int8, float16, int32)
        """
        self.model_size = model_size
        self.device = device
        self.use_faster = use_faster and FASTER_WHISPER_AVAILABLE
        self.compute_type = compute_type
        self._model = None
        self._model_type = None

        logger.info(f"ASR Service initialized with model={model_size}, device={device}")

    @property
    def model(self):
        """Lazy load the Whisper model."""
        if self._model is None:
            self._load_model()
        return self._model

    def _load_model(self):
        """Load the Whisper model."""
        if self.use_faster:
            logger.info(f"Loading faster-whisper model: {self.model_size}")
            try:
                # Determine compute type based on device
                if self.device == "cuda" and torch.cuda.is_available():
                    compute_type = "float16"
                else:
                    compute_type = "int8"

                self._model = WhisperModel(
                    self.model_size,
                    device=self.device,
                    compute_type=compute_type
                )
                self._model_type = "faster-whisper"
                logger.info("faster-whisper model loaded successfully")
            except Exception as e:
                logger.warning(f"Failed to load faster-whisper: {e}, falling back to openai-whisper")
                self.use_faster = False

        if not self.use_faster and OPENAI_WHISPER_AVAILABLE:
            logger.info(f"Loading openai-whisper model: {self.model_size}")
            try:
                self._model = whisper.load_model(self.model_size, device=self.device)
                self._model_type = "openai-whisper"
                logger.info("openai-whisper model loaded successfully")
            except Exception as e:
                logger.error(f"Failed to load openai-whisper: {e}")
                raise RuntimeError("Failed to load any Whisper model")

        if not OPENAI_WHISPER_AVAILABLE and not FASTER_WHISPER_AVAILABLE:
            raise RuntimeError(
                "No Whisper implementation available. "
                "Install with: pip install openai-whisper or pip install faster-whisper"
            )

    def transcribe(
        self,
        audio_input: Union[str, Path, bytes, np.ndarray],
        language: Optional[str] = None,
        task: str = "transcribe",
        **kwargs
    ) -> dict:
        """
        Transcribe audio to text.

        Args:
            audio_input: Audio file path, bytes, or numpy array
            language: Language code (e.g., 'en', 'es'). None for auto-detect.
            task: 'transcribe' or 'translate' (to English)
            **kwargs: Additional parameters passed to the model

        Returns:
            Dict with 'text', 'language', and optionally 'segments'
        """
        # Handle bytes input - save to temp file
        if isinstance(audio_input, bytes):
            with tempfile.NamedTemporaryFile(delete=False, suffix=".wav") as f:
                f.write(audio_input)
                temp_path = f.name
            try:
                result = self.transcribe(temp_path, language=language, task=task, **kwargs)
            finally:
                os.unlink(temp_path)
            return result

        # Handle file path or Path object
        audio_path = str(audio_input)

        if self._model_type == "faster-whisper":
            return self._transcribe_faster(audio_path, language, task, **kwargs)
        else:
            return self._transcribe_openai(audio_path, language, task, **kwargs)

    def _transcribe_faster(
        self,
        audio_path: str,
        language: Optional[str],
        task: str,
        **kwargs
    ) -> dict:
        """Transcribe using faster-whisper."""
        options = {
            "language": language,
            "task": task,
            "vad_filter": True,  # Voice Activity Detection
            "word_timestamps": kwargs.get("word_timestamps", False),
        }

        # Add additional options
        if "beam_size" in kwargs:
            options["beam_size"] = kwargs["beam_size"]
        if "best_of" in kwargs:
            options["best_of"] = kwargs["best_of"]

        segments, info = self.model.transcribe(audio_path, **options)

        # Collect results
        full_text = []
        segment_data = []

        for segment in segments:
            full_text.append(segment.text)
            if kwargs.get("return_segments", False):
                segment_data.append({
                    "start": segment.start,
                    "end": segment.end,
                    "text": segment.text
                })

        return {
            "text": " ".join(full_text),
            "language": info.language,
            "language_probability": info.language_probability,
            "segments": segment_data if segment_data else None,
            "model": f"faster-whisper-{self.model_size}"
        }

    def _transcribe_openai(
        self,
        audio_path: str,
        language: Optional[str],
        task: str,
        **kwargs
    ) -> dict:
        """Transcribe using openai-whisper."""
        options = {
            "language": language,
            "task": task,
            "fp16": kwargs.get("fp16", self.device == "cuda"),
        }

        # Add additional options
        if "temperature" in kwargs:
            options["temperature"] = kwargs["temperature"]

        result = self.model.transcribe(audio_path, **options)

        segment_data = None
        if kwargs.get("return_segments", False) and "segments" in result:
            segment_data = [
                {"start": s["start"], "end": s["end"], "text": s["text"]}
                for s in result["segments"]
            ]

        return {
            "text": result["text"].strip(),
            "language": result.get("language", "unknown"),
            "segments": segment_data,
            "model": f"openai-whisper-{self.model_size}"
        }

    def transcribe_streaming(self, audio_generator):
        """
        Transcribe audio from a generator (for streaming input).

        Args:
            audio_generator: Generator yielding audio chunks

        Yields:
            Transcription results as they become available
        """
        # Note: Full streaming transcription requires additional setup
        # This is a placeholder for future implementation
        raise NotImplementedError("Streaming transcription not yet implemented")


class ASRResult:
    """Container for ASR transcription results."""

    def __init__(
        self,
        text: str,
        language: str,
        confidence: float = 1.0,
        segments: Optional[list] = None,
        model: str = ""
    ):
        self.text = text
        self.language = language
        self.confidence = confidence
        self.segments = segments or []
        self.model = model

    def to_dict(self) -> dict:
        """Convert to dictionary."""
        return {
            "text": self.text,
            "language": self.language,
            "confidence": self.confidence,
            "segments": self.segments,
            "model": self.model
        }


# Global ASR service instance
_asr_service: Optional[ASRService] = None


def get_asr_service() -> ASRService:
    """Get or create the global ASR service instance."""
    global _asr_service
    if _asr_service is None:
        from backend.core.config import settings
        _asr_service = ASRService(
            model_size=settings.WHISPER_MODEL,
            device=settings.WHISPER_DEVICE,
            use_faster=settings.USE_FASTER_WHISPER
        )
    return _asr_service


async def transcribe_audio(
    audio_data: Union[str, Path, bytes],
    language: Optional[str] = None
) -> ASRResult:
    """
    Transcribe audio data using the global ASR service.

    Args:
        audio_data: Audio file path or bytes
        language: Optional language code

    Returns:
        ASRResult with transcription
    """
    service = get_asr_service()
    result = service.transcribe(audio_data, language=language)

    return ASRResult(
        text=result["text"],
        language=result.get("language", "unknown"),
        confidence=result.get("language_probability", 1.0),
        segments=result.get("segments"),
        model=result.get("model", "")
    )

"""
Text-to-Speech (TTS) Service using local engines.
Supports Edge-TTS (Microsoft), pyttsx3, and optionally OpenAI TTS.
"""
import os
import logging
import tempfile
import asyncio
from pathlib import Path
from typing import Optional, List
import threading

logger = logging.getLogger(__name__)

try:
    import edge_tts
    EDGE_TTS_AVAILABLE = True
except ImportError:
    EDGE_TTS_AVAILABLE = False

try:
    import pyttsx3
    PYTTSX3_AVAILABLE = True
except ImportError:
    PYTTSX3_AVAILABLE = False


class TTSEngine:
    """Base class for TTS engines."""

    def __init__(self, voice: str = "", rate: int = 0):
        self.voice = voice
        self.rate = rate
        self._engine = None

    async def synthesize(self, text: str, output_path: Optional[str] = None) -> str:
        """
        Synthesize speech from text.

        Args:
            text: Text to synthesize
            output_path: Optional output file path

        Returns:
            Path to the generated audio file
        """
        raise NotImplementedError

    def get_available_voices(self) -> List[str]:
        """Get list of available voices."""
        raise NotImplementedError

    async def close(self):
        """Clean up resources."""
        pass


class EdgeTTSEngine(TTSEngine):
    """
    TTS engine using Microsoft Edge's online TTS service.
    High quality, requires internet connection.
    """

    def __init__(self, voice: str = "en-US-AriaNeural", rate: int = 0):
        super().__init__(voice, rate)
        if not EDGE_TTS_AVAILABLE:
            raise ImportError("edge-tts is not installed. Install with: pip install edge-tts")

        # Validate voice format
        if not self.voice:
            self.voice = "en-US-AriaNeural"

    async def synthesize(self, text: str, output_path: Optional[str] = None) -> str:
        """Synthesize speech using Edge TTS."""
        if output_path is None:
            output_path = tempfile.mktemp(suffix=".mp3")

        communicate = edge_tts.Communicate(text, self.voice)

        await communicate.save(output_path)

        logger.debug(f"Generated TTS audio: {output_path} ({len(text)} chars)")
        return output_path

    def get_available_voices(self) -> List[str]:
        """Get available Edge TTS voices (cached list)."""
        # Common English voices
        return [
            "en-US-AriaNeural",  # Female
            "en-US-GuyNeural",   # Male
            "en-GB-SoniaNeural", # UK Female
            "en-GB-RyanNeural",  # UK Male
            "en-AU-NatashaNeural", # Australian Female
            "en-IN-NeerjaNeural",  # Indian Female
        ]


class Pyttsx3Engine(TTSEngine):
    """
    TTS engine using pyttsx3 (offline, system voices).
    Lower quality but works offline.
    """

    def __init__(self, voice: str = "", rate: int = 0):
        super().__init__(voice, rate)
        if not PYTTSX3_AVAILABLE:
            raise ImportError("pyttsx3 is not installed. Install with: pip install pyttsx3")

        self._engine = pyttsx3.init()
        self._configure_engine()

    def _configure_engine(self):
        """Configure the pyttsx3 engine."""
        voices = self._engine.getProperty('voices')
        if voices:
            if self.voice:
                # Try to find matching voice
                for v in voices:
                    if self.voice.lower() in v.id.lower():
                        self._engine.setProperty('voice', v.id)
                        break
            else:
                # Use first available voice
                self._engine.setProperty('voice', voices[0].id)

        # Set speech rate (default is usually 200)
        if self.rate != 0:
            current_rate = self._engine.getProperty('rate')
            self._engine.setProperty('rate', current_rate + self.rate)

    async def synthesize(self, text: str, output_path: Optional[str] = None) -> str:
        """Synthesize speech using pyttsx3."""
        if output_path is None:
            output_path = tempfile.mktemp(suffix=".wav")

        # pyttsx3 is synchronous, run in thread pool
        def _save_to_file():
            self._engine.save_to_file(text, output_path)
            self._engine.runAndWait()

        loop = asyncio.get_event_loop()
        await loop.run_in_executor(None, _save_to_file)

        logger.debug(f"Generated TTS audio: {output_path} ({len(text)} chars)")
        return output_path

    def get_available_voices(self) -> List[str]:
        """Get available system voices."""
        voices = self._engine.getProperty('voices')
        return [v.id for v in voices] if voices else []

    async def close(self):
        """Clean up the pyttsx3 engine."""
        if self._engine:
            self._engine.stop()


class TTSResponse:
    """Container for TTS synthesis results."""

    def __init__(
        self,
        audio_path: str,
        text: str,
        engine: str,
        voice: str,
        duration: Optional[float] = None
    ):
        self.audio_path = audio_path
        self.text = text
        self.engine = engine
        self.voice = voice
        self.duration = duration

    def to_dict(self) -> dict:
        """Convert to dictionary."""
        return {
            "audio_path": self.audio_path,
            "text": self.text,
            "engine": self.engine,
            "voice": self.voice,
            "duration": self.duration
        }


class TTSService:
    """
    Text-to-Speech service supporting multiple engines.
    """

    def __init__(
        self,
        engine: str = "edge",
        voice: str = "",
        rate: int = 0
    ):
        """
        Initialize the TTS service.

        Args:
            engine: TTS engine to use ('edge', 'pyttsx3', 'auto')
            voice: Voice name (empty for default)
            rate: Speech rate adjustment
        """
        self.engine_name = engine
        self.voice = voice
        self.rate = rate
        self._engine: Optional[TTSEngine] = None
        self._lock = threading.Lock()

        logger.info(f"TTS Service initialized with engine={engine}")

    @property
    def engine(self) -> TTSEngine:
        """Get or create the TTS engine."""
        if self._engine is None:
            self._engine = self._create_engine()
        return self._engine

    def _create_engine(self) -> TTSEngine:
        """Create the appropriate TTS engine."""
        engine_type = self.engine_name.lower()

        if engine_type == "auto":
            # Auto-select: prefer edge-tts, fallback to pyttsx3
            if EDGE_TTS_AVAILABLE:
                return EdgeTTSEngine(voice=self.voice, rate=self.rate)
            elif PYTTSX3_AVAILABLE:
                logger.info("edge-tts not available, using pyttsx3")
                return Pyttsx3Engine(voice=self.voice, rate=self.rate)
            else:
                raise RuntimeError("No TTS engine available")

        if engine_type == "edge":
            return EdgeTTSEngine(voice=self.voice, rate=self.rate)
        elif engine_type == "pyttsx3":
            return Pyttsx3Engine(voice=self.voice, rate=self.rate)
        else:
            raise ValueError(f"Unknown TTS engine: {engine_type}")

    async def synthesize(
        self,
        text: str,
        output_path: Optional[str] = None
    ) -> TTSResponse:
        """
        Synthesize speech from text.

        Args:
            text: Text to synthesize
            output_path: Optional output file path

        Returns:
            TTSResponse with audio file path
        """
        if not text or not text.strip():
            raise ValueError("Cannot synthesize empty text")

        # Clean text for TTS
        text = text.strip()
        text = text.replace("*", "").replace("#", "")  # Remove markdown

        with self._lock:
            audio_path = await self.engine.synthesize(text, output_path)

        return TTSResponse(
            audio_path=audio_path,
            text=text,
            engine=self.engine_name,
            voice=self.voice or "default"
        )

    def get_available_voices(self) -> List[str]:
        """Get list of available voices."""
        try:
            return self.engine.get_available_voices()
        except Exception as e:
            logger.warning(f"Failed to get voices: {e}")
            return []

    async def close(self):
        """Clean up resources."""
        if self._engine:
            await self._engine.close()


# Global TTS service instance
_tts_service: Optional[TTSService] = None


def get_tts_service() -> TTSService:
    """Get or create the global TTS service instance."""
    global _tts_service
    if _tts_service is None:
        from backend.core.config import settings
        _tts_service = TTSService(
            engine=settings.TTS_ENGINE,
            voice=settings.TTS_VOICE,
            rate=settings.TTS_RATE
        )
    return _tts_service


async def synthesize_speech(
    text: str,
    output_path: Optional[str] = None
) -> TTSResponse:
    """
    Synthesize speech from text using the global TTS service.

    Args:
        text: Text to synthesize
        output_path: Optional output file path

    Returns:
        TTSResponse with audio file path
    """
    service = get_tts_service()
    return await service.synthesize(text, output_path)

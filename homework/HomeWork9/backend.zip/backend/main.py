"""
Backend main entry point.
Can be run directly or imported as a module.
"""
import sys
from pathlib import Path

# Add project root to path
PROJECT_ROOT = Path(__file__).parent.parent
sys.path.insert(0, str(PROJECT_ROOT))


def main():
    """Main entry point for the backend server."""
    import uvicorn
    from backend.core.config import settings

    print("=" * 60)
    print("  Academic Research Assistant - Backend API")
    print("=" * 60)
    print(f"  Host: {settings.API_HOST}")
    print(f"  Port: {settings.API_PORT}")
    print(f"  Model: {settings.OPENAI_MODEL}")
    print(f"  TTS Engine: {settings.TTS_ENGINE}")
    print("=" * 60)
    print()

    uvicorn.run(
        "backend.api.server:app",
        host=settings.API_HOST,
        port=settings.API_PORT,
        reload=True,
        log_level="info"
    )


if __name__ == "__main__":
    main()

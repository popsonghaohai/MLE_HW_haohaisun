"""Core modules for the Academic Research Assistant."""

from .config import settings

__all__ = ["settings"]

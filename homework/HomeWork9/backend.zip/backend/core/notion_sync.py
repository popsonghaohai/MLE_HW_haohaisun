"""
Notion Integration - Sync sessions and summaries to Notion database.
Automatically logs conversations and saves research summaries.
"""
import logging
from typing import Optional, List, Dict, Any
from datetime import datetime
from dataclasses import dataclass

try:
    from notion_client import Client as NotionClient
    NOTION_AVAILABLE = True
except ImportError:
    NOTION_AVAILABLE = False

logger = logging.getLogger(__name__)


@dataclass
class NotionPage:
    """Container for Notion page data."""
    page_id: str
    url: str
    title: str
    created_at: datetime


class NotionSync:
    """
    Manages synchronization with Notion for session persistence.
    Creates pages in a Notion database for each research session.
    """

    def __init__(
        self,
        api_key: str,
        database_id: str,
        enabled: bool = True
    ):
        """
        Initialize Notion sync.

        Args:
            api_key: Notion API key
            database_id: Notion database ID
            enabled: Whether Notion sync is enabled
        """
        self.api_key = api_key
        self.database_id = database_id
        self.enabled = enabled and NOTION_AVAILABLE

        if self.enabled:
            self.client = NotionClient(auth=api_key)
            logger.info("Notion sync enabled")
        else:
            self.client = None
            logger.warning("Notion sync disabled")

    async def create_session_page(
        self,
        session_id: str,
        title: str,
        metadata: Dict = None
    ) -> Optional[NotionPage]:
        """
        Create a new page in Notion for a session.

        Args:
            session_id: Session identifier
            title: Session title
            metadata: Optional metadata

        Returns:
            NotionPage if successful, None otherwise
        """
        if not self.enabled:
            return None

        try:
            # Create page in database
            page_data = {
                "parent": {"database_id": self.database_id},
                "properties": {
                    "title": {
                        "title": [
                            {
                                "text": {
                                    "content": title or f"Session {session_id[:8]}"
                                }
                            }
                        ]
                    },
                    "Session ID": {
                        "rich_text": [
                            {
                                "text": {"content": session_id}
                            }
                        ]
                    },
                    "Date": {
                        "date": {"start": datetime.utcnow().isoformat()}
                    }
                }
            }

            # Add tags if provided
            if metadata and "tags" in metadata:
                page_data["properties"]["Tags"] = {
                    "multi_select": [{"name": tag} for tag in metadata["tags"]]
                }

            response = self.client.pages.create(**page_data)

            page = NotionPage(
                page_id=response["id"],
                url=response["url"],
                title=title,
                created_at=datetime.utcnow()
            )

            logger.info(f"Created Notion page: {page.url}")
            return page

        except Exception as e:
            logger.error(f"Failed to create Notion page: {e}")
            return None

    async def append_conversation(
        self,
        page_id: str,
        messages: List[Dict[str, Any]]
    ) -> bool:
        """
        Append conversation log to a Notion page.

        Args:
            page_id: Notion page ID
            messages: List of message dicts

        Returns:
            True if successful
        """
        if not self.enabled:
            return False

        try:
            # Build conversation content
            blocks = [
                {
                    "object": "block",
                    "type": "heading_2",
                    "heading_2": {
                        "rich_text": [{"type": "text", "text": {"content": "Conversation Log"}}]
                    }
                }
            ]

            for msg in messages:
                role = msg.get("role", "unknown").capitalize()
                content = msg.get("content", "")
                timestamp = msg.get("timestamp", "")

                blocks.append({
                    "object": "block",
                    "type": "heading_3",
                    "heading_3": {
                        "rich_text": [
                            {"type": "text", "text": {"content": f"{role}"}}
                        ]
                    }
                })

                blocks.append({
                    "object": "block",
                    "type": "paragraph",
                    "paragraph": {
                        "rich_text": [{"type": "text", "text": {"content": content}}]
                    }
                })

            # Append blocks to page
            self.client.blocks.children.append(block_id=page_id, children=blocks)

            logger.debug(f"Appended {len(messages)} messages to Notion page {page_id}")
            return True

        except Exception as e:
            logger.error(f"Failed to append conversation: {e}")
            return False

    async def append_summary(
        self,
        page_id: str,
        summary: str,
        papers: List[Dict] = None
    ) -> bool:
        """
        Append research summary to a Notion page.

        Args:
            page_id: Notion page ID
            summary: Summary text
            papers: Optional list of papers referenced

        Returns:
            True if successful
        """
        if not self.enabled:
            return False

        try:
            blocks = [
                {
                    "object": "block",
                    "type": "heading_2",
                    "heading_2": {
                        "rich_text": [{"type": "text", "text": {"content": "Summary"}}]
                    }
                },
                {
                    "object": "block",
                    "type": "paragraph",
                    "paragraph": {
                        "rich_text": [{"type": "text", "text": {"content": summary}}]
                    }
                }
            ]

            # Add papers if provided
            if papers:
                blocks.append({
                    "object": "block",
                    "type": "heading_2",
                    "heading_2": {
                        "rich_text": [{"type": "text", "text": {"content": "Referenced Papers"}}]
                    }
                })

                for paper in papers[:10]:  # Limit to 10 papers
                    title = paper.get("title", "Unknown")
                    url = paper.get("url", "")
                    authors = paper.get("authors", [])

                    paper_text = f"**{title}**\n"
                    paper_text += f"Authors: {', '.join(authors[:3])}"
                    if len(authors) > 3:
                        paper_text += " et al."
                    paper_text += f"\nURL: {url}"

                    blocks.append({
                        "object": "block",
                        "type": "bulleted_list_item",
                        "bulleted_list_item": {
                            "rich_text": [{"type": "text", "text": {"content": paper_text}}]
                        }
                    })

            self.client.blocks.children.append(block_id=page_id, children=blocks)

            logger.info(f"Appended summary to Notion page {page_id}")
            return True

        except Exception as e:
            logger.error(f"Failed to append summary: {e}")
            return False

    async def sync_session(
        self,
        session_id: str,
        title: str,
        messages: List[Dict],
        summary: str = None,
        papers: List[Dict] = None,
        metadata: Dict = None
    ) -> Optional[str]:
        """
        Full sync of a session to Notion.

        Args:
            session_id: Session identifier
            title: Session title
            messages: Conversation messages
            summary: Optional summary
            papers: Optional referenced papers
            metadata: Optional metadata

        Returns:
            Notion page URL if successful, None otherwise
        """
        if not self.enabled:
            logger.debug("Notion sync is disabled")
            return None

        try:
            # Create page
            page = await self.create_session_page(session_id, title, metadata)
            if not page:
                return None

            # Append conversation
            if messages:
                await self.append_conversation(page.page_id, messages)

            # Append summary
            if summary:
                await self.append_summary(page.page_id, summary, papers)

            return page.url

        except Exception as e:
            logger.error(f"Failed to sync session: {e}")
            return None

    async def add_paper_to_database(
        self,
        paper: Dict[str, Any]
    ) -> Optional[str]:
        """
        Add a paper to the Notion database.

        Args:
            paper: Paper dict with title, authors, abstract, etc.

        Returns:
            Page URL if successful
        """
        if not self.enabled:
            return None

        try:
            page_data = {
                "parent": {"database_id": self.database_id},
                "properties": {
                    "title": {
                        "title": [
                            {
                                "text": {"content": paper.get("title", "Unknown")}
                            }
                        ]
                    },
                    "Authors": {
                        "rich_text": [
                            {
                                "text": {
                                    "content": ", ".join(paper.get("authors", [])[:5])
                                }
                            }
                        ]
                    },
                    "Abstract": {
                        "rich_text": [
                            {
                                "text": {"content": paper.get("abstract", paper.get("summary", ""))[:2000]}
                            }
                        ]
                    },
                    "ArXiv ID": {
                        "rich_text": [
                            {
                                "text": {"content": paper.get("arxiv_id", "")}
                            }
                        ]
                    }
                }
            }

            # Add URL if available
            if paper.get("url"):
                page_data["properties"]["URL"] = {
                    "url": paper["url"]
                }

            response = self.client.pages.create(**page_data)
            return response["url"]

        except Exception as e:
            logger.error(f"Failed to add paper to Notion: {e}")
            return None


# Global Notion sync instance
_notion_sync: Optional[NotionSync] = None


def get_notion_sync() -> NotionSync:
    """Get or create the global Notion sync instance."""
    global _notion_sync
    if _notion_sync is None:
        from backend.core.config import settings
        _notion_sync = NotionSync(
            api_key=settings.NOTION_API_KEY,
            database_id=settings.NOTION_DATABASE_ID,
            enabled=settings.ENABLE_NOTION_SYNC
        )
    return _notion_sync

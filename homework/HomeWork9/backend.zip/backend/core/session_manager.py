"""
Session Manager - Manage conversation sessions with context history.
Handles multi-turn conversations and context window management.
"""
import logging
import uuid
from datetime import datetime, timedelta
from typing import Optional, List, Dict, Any
from dataclasses import dataclass, field, asdict
from pathlib import Path
import json

logger = logging.getLogger(__name__)


@dataclass
class ChatMessage:
    """Single message in a conversation."""
    role: str  # user, assistant, system, tool
    content: str
    timestamp: datetime = field(default_factory=datetime.utcnow)
    metadata: Dict = field(default_factory=dict)

    def to_dict(self) -> Dict:
        """Convert to dictionary."""
        return {
            "role": self.role,
            "content": self.content,
            "timestamp": self.timestamp.isoformat(),
            "metadata": self.metadata
        }


@dataclass
class Session:
    """A conversation session."""
    session_id: str
    created_at: datetime = field(default_factory=datetime.utcnow)
    updated_at: datetime = field(default_factory=datetime.utcnow)
    messages: List[ChatMessage] = field(default_factory=list)
    metadata: Dict = field(default_factory=dict)
    title: Optional[str] = None

    def add_message(self, role: str, content: str, metadata: Dict = None):
        """Add a message to the session."""
        message = ChatMessage(
            role=role,
            content=content,
            metadata=metadata or {}
        )
        self.messages.append(message)
        self.updated_at = datetime.utcnow()

        # Generate title from first user message if not set
        if self.title is None and role == "user":
            self.title = content[:50] + "..." if len(content) > 50 else content

    def get_recent_messages(self, limit: int = 20) -> List[ChatMessage]:
        """Get recent messages."""
        return self.messages[-limit:] if self.messages else []

    def get_conversation_context(self, max_messages: int = 10) -> str:
        """Get formatted conversation context for LLM."""
        recent = self.get_recent_messages(max_messages)
        context_parts = []
        for msg in recent:
            if msg.role in ("user", "assistant"):
                context_parts.append(f"{msg.role.capitalize()}: {msg.content}")
        return "\n\n".join(context_parts)

    def to_dict(self) -> Dict:
        """Convert to dictionary."""
        return {
            "session_id": self.session_id,
            "created_at": self.created_at.isoformat(),
            "updated_at": self.updated_at.isoformat(),
            "title": self.title,
            "messages": [m.to_dict() for m in self.messages],
            "metadata": self.metadata
        }


class SessionManager:
    """
    Manages conversation sessions with persistence.
    """

    def __init__(
        self,
        storage_dir: str = None,
        max_history: int = 100,
        session_timeout_minutes: int = 60
    ):
        """
        Initialize the session manager.

        Args:
            storage_dir: Directory to store session files
            max_history: Maximum messages to keep per session
            session_timeout_minutes: Minutes before a session is considered stale
        """
        self.storage_dir = Path(storage_dir) if storage_dir else Path("./data/sessions")
        self.storage_dir.mkdir(parents=True, exist_ok=True)
        self.max_history = max_history
        self.session_timeout = timedelta(minutes=session_timeout_minutes)

        # In-memory session cache
        self._sessions: Dict[str, Session] = {}

        logger.info(f"SessionManager initialized: storage={self.storage_dir}")

    def create_session(self, session_id: Optional[str] = None, metadata: Dict = None) -> Session:
        """
        Create a new session.

        Args:
            session_id: Optional custom session ID
            metadata: Optional metadata

        Returns:
            New Session object
        """
        sid = session_id or str(uuid.uuid4())
        session = Session(
            session_id=sid,
            metadata=metadata or {}
        )
        self._sessions[sid] = session
        logger.info(f"Created session: {sid}")
        return session

    def get_session(self, session_id: str) -> Optional[Session]:
        """
        Get a session by ID.

        Args:
            session_id: Session ID

        Returns:
            Session object or None
        """
        # Check in-memory cache first
        if session_id in self._sessions:
            return self._sessions[session_id]

        # Try to load from storage
        session = self._load_session(session_id)
        if session:
            self._sessions[session_id] = session
            return session

        return None

    def add_message(
        self,
        session_id: str,
        role: str,
        content: str,
        metadata: Dict = None
    ) -> Optional[Session]:
        """
        Add a message to a session.

        Args:
            session_id: Session ID
            role: Message role (user, assistant, etc.)
            content: Message content
            metadata: Optional metadata

        Returns:
            Updated Session or None
        """
        session = self.get_session(session_id)
        if not session:
            logger.warning(f"Session not found: {session_id}")
            return None

        session.add_message(role, content, metadata)

        # Trim history if needed
        if len(session.messages) > self.max_history:
            session.messages = session.messages[-self.max_history:]

        # Auto-save after adding message
        self._save_session(session)

        return session

    def get_context_for_llm(
        self,
        session_id: str,
        max_messages: int = 10
    ) -> List[Dict[str, str]]:
        """
        Get conversation context formatted for LLM.

        Args:
            session_id: Session ID
            max_messages: Maximum messages to include

        Returns:
            List of message dicts in OpenAI format
        """
        session = self.get_session(session_id)
        if not session:
            return []

        messages = []
        for msg in session.get_recent_messages(max_messages):
            if msg.role in ("user", "assistant", "system"):
                messages.append({
                    "role": msg.role,
                    "content": msg.content
                })

        return messages

    def list_sessions(self, limit: int = 50) -> List[Session]:
        """List recent sessions."""
        # Combine in-memory and stored sessions
        all_sessions = list(self._sessions.values())

        # Load from storage for more results
        for session_file in self.storage_dir.glob("*.json"):
            try:
                sid = session_file.stem
                if sid not in self._sessions:
                    session = self._load_session(sid)
                    if session:
                        all_sessions.append(session)
            except Exception as e:
                logger.warning(f"Failed to load session file {session_file}: {e}")

        # Sort by updated_at
        all_sessions.sort(key=lambda s: s.updated_at, reverse=True)
        return all_sessions[:limit]

    def delete_session(self, session_id: str) -> bool:
        """Delete a session."""
        # Remove from cache
        if session_id in self._sessions:
            del self._sessions[session_id]

        # Remove from storage
        session_file = self.storage_dir / f"{session_id}.json"
        if session_file.exists():
            session_file.unlink()
            logger.info(f"Deleted session: {session_id}")
            return True

        return False

    def cleanup_stale_sessions(self) -> int:
        """Remove stale sessions older than timeout."""
        cutoff = datetime.utcnow() - self.session_timeout
        removed = 0

        for session_id, session in list(self._sessions.items()):
            if session.updated_at < cutoff:
                self.delete_session(session_id)
                removed += 1

        return removed

    def _save_session(self, session: Session) -> bool:
        """Save session to disk."""
        try:
            session_file = self.storage_dir / f"{session.session_id}.json"
            with open(session_file, 'w', encoding='utf-8') as f:
                json.dump(session.to_dict(), f, indent=2, ensure_ascii=False)
            return True
        except Exception as e:
            logger.error(f"Failed to save session {session.session_id}: {e}")
            return False

    def _load_session(self, session_id: str) -> Optional[Session]:
        """Load session from disk."""
        try:
            session_file = self.storage_dir / f"{session_id}.json"
            if not session_file.exists():
                return None

            with open(session_file, 'r', encoding='utf-8') as f:
                data = json.load(f)

            # Reconstruct Session object
            messages = [
                ChatMessage(
                    role=m["role"],
                    content=m["content"],
                    timestamp=datetime.fromisoformat(m["timestamp"]),
                    metadata=m.get("metadata", {})
                )
                for m in data.get("messages", [])
            ]

            session = Session(
                session_id=data["session_id"],
                created_at=datetime.fromisoformat(data["created_at"]),
                updated_at=datetime.fromisoformat(data["updated_at"]),
                messages=messages,
                metadata=data.get("metadata", {}),
                title=data.get("title")
            )

            return session

        except Exception as e:
            logger.error(f"Failed to load session {session_id}: {e}")
            return None

    def get_session_summary(self, session_id: str) -> Dict[str, Any]:
        """Get a summary of the session."""
        session = self.get_session(session_id)
        if not session:
            return {}

        # Count messages by role
        role_counts = {}
        for msg in session.messages:
            role_counts[msg.role] = role_counts.get(msg.role, 0) + 1

        return {
            "session_id": session.session_id,
            "title": session.title,
            "created_at": session.created_at.isoformat(),
            "updated_at": session.updated_at.isoformat(),
            "message_count": len(session.messages),
            "role_counts": role_counts,
            "metadata": session.metadata
        }


# Global session manager instance
_session_manager: Optional[SessionManager] = None


def get_session_manager() -> SessionManager:
    """Get or create the global session manager instance."""
    global _session_manager
    if _session_manager is None:
        from backend.core.config import settings
        _session_manager = SessionManager(
            storage_dir=str(settings.DATA_DIR / "sessions"),
            max_history=settings.MAX_CONTEXT_HISTORY,
            session_timeout_minutes=settings.SESSION_TIMEOUT_MINUTES
        )
    return _session_manager

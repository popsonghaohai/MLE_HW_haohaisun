"""
Configuration management for the Academic Research Assistant.
Loads settings from environment variables with sensible defaults.
"""
import os
from pathlib import Path
from typing import Optional
from dotenv import load_dotenv

# Load environment variables from .env file
load_dotenv()


class Settings:
    """Application settings loaded from environment variables."""

    # Base paths
    BASE_DIR: Path = Path(__file__).resolve().parent.parent.parent
    BACKEND_DIR: Path = BASE_DIR / "backend"
    DATA_DIR: Path = BASE_DIR / "data"
    AUDIO_DIR: Path = DATA_DIR / "audio"
    VECTOR_DB_DIR: Path = DATA_DIR / "vector_db"

    # OpenAI API
    OPENAI_API_KEY: str = os.getenv("OPENAI_API_KEY", "")
    OPENAI_MODEL: str = os.getenv("OPENAI_MODEL", "gpt-4o")
    OPENAI_EMBEDDING_MODEL: str = os.getenv("OPENAI_EMBEDDING_MODEL", "text-embedding-3-small")

    # Local LLM (Ollama)
    USE_LOCAL_LLM: bool = os.getenv("USE_LOCAL_LLM", "true").lower() == "true"
    LOCAL_LLM_BASE_URL: str = os.getenv("LOCAL_LLM_BASE_URL", "http://localhost:11434")
    LOCAL_LLM_MODEL: str = os.getenv("LOCAL_LLM_MODEL", "qwen3:8b")

    # Notion
    NOTION_API_KEY: str = os.getenv("NOTION_API_KEY", "")
    NOTION_DATABASE_ID: str = os.getenv("NOTION_DATABASE_ID", "")

    # Tavily (web search)
    TAVILY_API_KEY: str = os.getenv("TAVILY_API_KEY", "")

    # ArXiv
    ARXIV_CATEGORY: str = os.getenv("ARXIV_CATEGORY", "cs.CL")
    ARXIV_MAX_RESULTS: int = int(os.getenv("ARXIV_MAX_RESULTS", "10"))

    # Vector DB (ChromaDB)
    CHROMA_PERSIST_DIR: str = str(VECTOR_DB_DIR / "chroma")
    EMBEDDING_MODEL: str = os.getenv("EMBEDDING_MODEL", "sentence-transformers/all-MiniLM-L6-v2")

    # ASR (Whisper)
    WHISPER_MODEL: str = os.getenv("WHISPER_MODEL", "base")  # tiny, base, small, medium, large
    WHISPER_DEVICE: str = os.getenv("WHISPER_DEVICE", "cpu")  # cpu, cuda
    USE_FASTER_WHISPER: bool = os.getenv("USE_FASTER_WHISPER", "true").lower() == "true"

    # TTS
    TTS_ENGINE: str = os.getenv("TTS_ENGINE", "edge")  # edge, pyttsx3, openai
    TTS_VOICE: str = os.getenv("TTS_VOICE", "en-US-AriaNeural")  # For edge-tts
    TTS_RATE: int = int(os.getenv("TTS_RATE", "0"))  # Speech rate (+/- percentage)

    # API Server
    API_HOST: str = os.getenv("API_HOST", "0.0.0.0")
    API_PORT: int = int(os.getenv("API_PORT", "8000"))
    API_CORS_ORIGINS: list = os.getenv("API_CORS_ORIGINS", "http://localhost:3000,http://localhost:5173").split(",")

    # Session management
    MAX_CONTEXT_HISTORY: int = int(os.getenv("MAX_CONTEXT_HISTORY", "20"))
    SESSION_TIMEOUT_MINUTES: int = int(os.getenv("SESSION_TIMEOUT_MINUTES", "60"))

    # Feature flags
    ENABLE_NOTION_SYNC: bool = os.getenv("ENABLE_NOTION_SYNC", "true").lower() == "true"
    ENABLE_VECTOR_SEARCH: bool = os.getenv("ENABLE_VECTOR_SEARCH", "true").lower() == "true"
    ENABLE_WEB_SEARCH: bool = os.getenv("ENABLE_WEB_SEARCH", "true").lower() == "true"

    def __init__(self):
        """Create necessary directories on initialization."""
        self.DATA_DIR.mkdir(parents=True, exist_ok=True)
        self.AUDIO_DIR.mkdir(parents=True, exist_ok=True)
        self.VECTOR_DB_DIR.mkdir(parents=True, exist_ok=True)

    def validate(self) -> bool:
        """Validate that required settings are configured."""
        if self.ENABLE_NOTION_SYNC and not self.NOTION_API_KEY:
            raise ValueError("NOTION_API_KEY is required when Notion sync is enabled")
        if not self.OPENAI_API_KEY:
            raise ValueError("OPENAI_API_KEY is required for LLM functionality")
        return True


# Global settings instance
settings = Settings()

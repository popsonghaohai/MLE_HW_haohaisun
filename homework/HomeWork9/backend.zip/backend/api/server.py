"""
FastAPI Server - Main API server for the Academic Research Assistant.
Provides endpoints for chat, transcription, TTS, sessions, and tools.
"""
import sys
import os
from pathlib import Path

# CRITICAL: Add project root to Python path BEFORE any imports
_current_file = Path(__file__).resolve()
_project_root = _current_file.parent.parent.parent
if str(_project_root) not in sys.path:
    sys.path.insert(0, str(_project_root))

import logging
import io
import uuid
from typing import Optional, List, Dict, Any
from datetime import datetime

from fastapi import FastAPI, UploadFile, File, HTTPException, Depends, BackgroundTasks
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, StreamingResponse
from pydantic import BaseModel

# Now we can import from backend modules
# Import models - using direct imports
from backend.api.models import (
    ChatRequest, ChatResponse,
    TranscriptionResponse,
    TTSResponse, TTSRequest,
    CreateSessionRequest, SessionResponse, SessionListResponse,
    ArxivSearchRequest, WebSearchRequest, SummarizeRequest,
    VectorSearchRequest, VectorSearchResponse,
    HealthResponse, StatusResponse, ErrorResponse
)

# Import services
from backend.core.config import settings
from backend.core.session_manager import get_session_manager
from backend.core.notion_sync import get_notion_sync
from backend.services.asr import transcribe_audio, ASRResult
from backend.services.tts import synthesize_speech, TTSResponse as TTSAudioResponse
from backend.services.llm_router import get_llm_router, create_tool_definition
from backend.tools.arxiv_tool import search_arxiv
from backend.tools.web_search_tool import search_web
from backend.tools.summarizer import summarize_papers
from backend.services.vector_store import get_vector_store

# Setup logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

# Create FastAPI app
app = FastAPI(
    title="Academic Research Assistant API",
    description="Voice-enabled AI assistant for academic research",
    version="0.1.0"
)

# Configure CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.API_CORS_ORIGINS,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


# ============ Dependencies ============

async def get_dependencies():
    """Initialize services on startup."""
    # Initialize LLM router with tools
    llm_router = get_llm_router()

    # Register tools
    llm_router.register_tools([
        create_tool_definition(
            name="search_arxiv",
            description="Search academic papers on arXiv",
            parameters={
                "type": "object",
                "properties": {
                    "query": {"type": "string"},
                    "category": {"type": "string"},
                    "max_results": {"type": "integer"},
                    "sort_by": {"type": "string"}
                },
                "required": ["query"]
            },
            async_function=search_arxiv
        ),
        create_tool_definition(
            name="search_web",
            description="Search the web for academic information",
            parameters={
                "type": "object",
                "properties": {
                    "query": {"type": "string"},
                    "max_results": {"type": "integer"},
                    "search_depth": {"type": "string"}
                },
                "required": ["query"]
            },
            async_function=search_web
        ),
        create_tool_definition(
            name="summarize_papers",
            description="Summarize and synthesize research papers",
            parameters={
                "type": "object",
                "properties": {
                    "papers": {"type": "array", "items": {"type": "object"}},
                    "focus": {"type": "string"},
                    "compare": {"type": "boolean"}
                },
                "required": ["papers"]
            },
            async_function=summarize_papers
        )
    ])

    logger.info("Services initialized")


# ============ Startup ============

@app.on_event("startup")
async def startup_event():
    """Initialize services on startup."""
    await get_dependencies()
    logger.info("API server started")


# ============ Health & Status ============

@app.get("/health", response_model=HealthResponse)
async def health_check():
    """Health check endpoint."""
    return HealthResponse(
        status="healthy",
        version="0.1.0",
        services={
            "asr": True,
            "tts": True,
            "llm": bool(settings.OPENAI_API_KEY),
            "notion": settings.ENABLE_NOTION_SYNC and bool(settings.NOTION_API_KEY),
            "vector_db": settings.ENABLE_VECTOR_SEARCH
        }
    )


@app.get("/api/status", response_model=StatusResponse)
async def get_status():
    """Get system status."""
    from backend.api.routes.status import get_system_status
    return await get_system_status()


# ============ Chat Endpoints ============

@app.post("/api/chat", response_model=ChatResponse)
async def chat_completion(request: ChatRequest, background_tasks: BackgroundTasks):
    """
    Main chat endpoint with tool calling and RAG.

    Processes user messages, routes to appropriate tools,
    and returns synthesized responses with vector store context.
    """
    try:
        session_manager = get_session_manager()
        llm_router = get_llm_router()

        # Get or create session
        session = session_manager.get_session(request.session_id)
        if not session:
            session = session_manager.create_session()
            request.session_id = session.session_id

        # Add user message to session
        session_manager.add_message(
            session.session_id,
            "user",
            request.message
        )

        # Get conversation context
        context = session_manager.get_context_for_llm(session.session_id)

        # Get RAG context from vector store if enabled
        rag_context = ""
        if settings.ENABLE_VECTOR_SEARCH:
            try:
                vector_store = get_vector_store()
                rag_context = vector_store.get_context_for_query(
                    query=request.message,
                    n_results=3,
                    max_tokens=1500
                )
                logger.info(f"RAG context length: {len(rag_context)}, starts with: {rag_context[:100] if rag_context else 'None'}...")
                if rag_context and rag_context != "No relevant context found in the knowledge base.":
                    logger.info(f"Retrieved RAG context for query: {request.message[:50]}...")
            except Exception as e:
                logger.warning(f"RAG context retrieval failed: {e}")

        # Build full message with context for LLM
        full_message = request.message
        context_parts = []

        if rag_context:
            context_parts.append(f"Relevant information from knowledge base:\n{rag_context}\n")

        if context:
            context_parts.append(f"Conversation context:\n{context}\n")

        if context_parts:
            full_message = f"{request.message}\n\n---\n{chr(10).join(context_parts)}"

        # Process through LLM router
        response_text = ""
        tool_calls_made = []

        async for chunk in llm_router.chat(
            full_message,
            tools_to_use=request.tools_to_use,
            original_message=request.message  # Pass original message for tool detection
        ):
            response_text += chunk

        # Extract tool calls from router
        # (In a real implementation, you'd track this properly)

        # Add assistant response to session
        session_manager.add_message(
            session.session_id,
            "assistant",
            response_text
        )

        # Handle TTS if requested
        audio_url = None
        if request.voice_input and response_text:
            try:
                # Generate unique filename and save to AUDIO_DIR
                import uuid
                audio_filename = f"{uuid.uuid4()}.mp3"
                audio_output_path = str(settings.AUDIO_DIR / audio_filename)

                tts_result = await synthesize_speech(response_text, output_path=audio_output_path)
                audio_url = f"/api/audio/{audio_filename}"
            except Exception as e:
                logger.warning(f"TTS generation failed: {e}")

        # Sync to Notion in background
        if settings.ENABLE_NOTION_SYNC:
            background_tasks.add_task(
                sync_session_to_notion,
                session.session_id,
                session.title or "Research Session",
                session.get_conversation_context()
            )

        return ChatResponse(
            response=response_text,
            session_id=session.session_id,
            tool_calls=tool_calls_made,
            audio_url=audio_url
        )

    except Exception as e:
        logger.error(f"Chat error: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/api/chat/stream")
async def chat_stream(request: ChatRequest):
    """Streaming chat endpoint for real-time responses."""
    # TODO: Implement Server-Sent Events or WebSocket streaming
    raise HTTPException(status_code=501, detail="Streaming not yet implemented")


# ============ Transcription Endpoint ============

@app.post("/api/transcribe", response_model=TranscriptionResponse)
async def transcribe_audio_endpoint(
    audio_file: UploadFile = File(...),
    language: Optional[str] = None
):
    """
    Transcribe audio file using Whisper ASR.

    Supports: wav, mp3, webm, ogg, flac
    """
    try:
        # Read audio file
        audio_data = await audio_file.read()

        # Transcribe
        result: ASRResult = await transcribe_audio(audio_data, language)

        return TranscriptionResponse(
            text=result.text,
            language=result.language,
            confidence=result.confidence,
            model=result.model
        )

    except Exception as e:
        logger.error(f"Transcription error: {e}")
        raise HTTPException(status_code=500, detail=str(e))


# ============ TTS Endpoint ============

@app.post("/api/tts", response_model=TTSResponse)
async def text_to_speech(request: TTSRequest):
    """
    Convert text to speech using TTS engine.

    Returns audio file URL for playback.
    """
    try:
        # Generate unique filename and save to AUDIO_DIR
        import uuid
        audio_filename = f"{uuid.uuid4()}.mp3"
        audio_output_path = str(settings.AUDIO_DIR / audio_filename)

        result: TTSAudioResponse = await synthesize_speech(
            request.text,
            output_path=audio_output_path
        )

        # Return relative URL path
        audio_url = f"/api/audio/{audio_filename}"

        return TTSResponse(
            audio_url=audio_url,
            text=request.text,
            engine=result.engine,
            voice=result.voice
        )

    except Exception as e:
        logger.error(f"TTS error: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/api/audio/{filename}")
async def get_audio(filename: str):
    """Serve generated audio files."""
    audio_path = settings.AUDIO_DIR / filename

    if not audio_path.exists():
        raise HTTPException(status_code=404, detail="Audio file not found")

    return FileResponse(audio_path)


# ============ Session Endpoints ============

@app.post("/api/sessions", response_model=SessionResponse)
async def create_session(request: CreateSessionRequest = None):
    """Create a new session."""
    try:
        session_manager = get_session_manager()

        session = session_manager.create_session(
            metadata=request.metadata if request else None
        )

        if request and request.title:
            session.title = request.title

        return SessionResponse(
            session_id=session.session_id,
            title=session.title,
            created_at=session.created_at,
            updated_at=session.updated_at,
            messages=[],
            message_count=0,
            metadata=session.metadata
        )

    except Exception as e:
        logger.error(f"Create session error: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/api/sessions/{session_id}", response_model=SessionResponse)
async def get_session(session_id: str):
    """Get session details."""
    try:
        session_manager = get_session_manager()
        session = session_manager.get_session(session_id)

        if not session:
            raise HTTPException(status_code=404, detail="Session not found")

        return SessionResponse(
            session_id=session.session_id,
            title=session.title,
            created_at=session.created_at,
            updated_at=session.updated_at,
            messages=[
                {
                    "role": msg.role,
                    "content": msg.content,
                    "timestamp": msg.timestamp
                }
                for msg in session.messages
            ],
            message_count=len(session.messages),
            metadata=session.metadata
        )

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Get session error: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/api/sessions", response_model=SessionListResponse)
async def list_sessions(limit: int = 50):
    """List all sessions."""
    try:
        session_manager = get_session_manager()
        sessions = session_manager.list_sessions(limit)

        return SessionListResponse(
            sessions=[
                SessionResponse(
                    session_id=s.session_id,
                    title=s.title,
                    created_at=s.created_at,
                    updated_at=s.updated_at,
                    messages=[
                        {
                            "role": msg.role,
                            "content": msg.content,
                            "timestamp": msg.timestamp
                        }
                        for msg in s.messages
                    ],
                    message_count=len(s.messages),
                    metadata=s.metadata
                )
                for s in sessions
            ],
            total=len(sessions)
        )

    except Exception as e:
        logger.error(f"List sessions error: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.delete("/api/sessions/{session_id}")
async def delete_session(session_id: str):
    """Delete a session."""
    try:
        session_manager = get_session_manager()
        success = session_manager.delete_session(session_id)

        if not success:
            raise HTTPException(status_code=404, detail="Session not found")

        return {"deleted": True, "session_id": session_id}

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Delete session error: {e}")
        raise HTTPException(status_code=500, detail=str(e))


# ============ Tool Endpoints ============

@app.post("/api/tools/arxiv")
async def arxiv_search(request: ArxivSearchRequest):
    """Search ArXiv for papers."""
    try:
        results = await search_arxiv(
            query=request.query,
            category=request.category,
            max_results=request.max_results,
            sort_by=request.sort_by
        )
        return {"results": results, "query": request.query}

    except Exception as e:
        logger.error(f"ArXiv search error: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/api/tools/web-search")
async def web_search(request: WebSearchRequest):
    """Search the web."""
    try:
        results = await search_web(
            query=request.query,
            max_results=request.max_results,
            search_depth=request.search_depth
        )
        return {"results": results, "query": request.query}

    except Exception as e:
        logger.error(f"Web search error: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/api/tools/summarize")
async def summarize(request: SummarizeRequest):
    """Summarize papers."""
    try:
        summary = await summarize_papers(
            papers=request.papers,
            focus=request.focus,
            compare=request.compare
        )
        return {"summary": summary}

    except Exception as e:
        logger.error(f"Summarization error: {e}")
        raise HTTPException(status_code=500, detail=str(e))


# ============ Vector Store Endpoints ============

@app.post("/api/vector/search", response_model=VectorSearchResponse)
async def vector_search(request: VectorSearchRequest):
    """Search vector database for relevant context."""
    try:
        if not settings.ENABLE_VECTOR_SEARCH:
            raise HTTPException(status_code=503, detail="Vector search disabled")

        vector_store = get_vector_store()
        results = vector_store.search(request.query, request.n_results)

        return VectorSearchResponse(
            results=results,
            query=request.query,
            count=len(results)
        )

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Vector search error: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/api/vector/index")
async def index_papers(rag_data_path: str):
    """Index RAG data into vector store."""
    try:
        from backend.services.vector_store import index_rag_data

        count = await index_rag_data(rag_data_path)
        return {"indexed": count, "path": rag_data_path}

    except Exception as e:
        logger.error(f"Index error: {e}")
        raise HTTPException(status_code=500, detail=str(e))


# ============ Background Tasks ============

async def sync_session_to_notion(session_id: str, title: str, context: str):
    """Sync session to Notion in background."""
    try:
        notion_sync = get_notion_sync()
        await notion_sync.sync_session(
            session_id=session_id,
            title=title,
            messages=[],  # You'd pass the actual messages here
            summary=context[:1000]  # Truncate for summary
        )
    except Exception as e:
        logger.warning(f"Notion sync failed: {e}")


# ============ Error Handlers ============

@app.exception_handler(Exception)
async def global_exception_handler(request, exc):
    """Global exception handler."""
    logger.error(f"Unhandled exception: {exc}")
    return ErrorResponse(
        error="Internal server error",
        detail=str(exc)
    )


# ============ Main Entry Point ============

if __name__ == "__main__":
    import uvicorn

    print("=" * 60)
    print("  Academic Research Assistant - Backend API")
    print("=" * 60)
    print(f"  Project root: {_project_root}")
    print(f"  API: http://{settings.API_HOST}:{settings.API_PORT}")
    print("=" * 60)

    uvicorn.run(
        app,
        host=settings.API_HOST,
        port=settings.API_PORT,
        log_level="info"
    )

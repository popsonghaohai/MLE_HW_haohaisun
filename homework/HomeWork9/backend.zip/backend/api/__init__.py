"""API package for the Academic Research Assistant."""

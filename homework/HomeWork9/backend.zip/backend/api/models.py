"""
Pydantic models for API requests and responses.
"""
from pydantic import BaseModel, Field
from typing import Optional, List, Dict, Any
from datetime import datetime


# ============ Chat Models ============

class ChatMessage(BaseModel):
    """Chat message in conversation."""
    role: str = Field(..., description="Message role: user, assistant, system")
    content: str = Field(..., description="Message content")
    timestamp: Optional[datetime] = None


class ChatRequest(BaseModel):
    """Request for chat completion."""
    message: str = Field(..., description="User message")
    session_id: Optional[str] = Field(None, description="Session ID for context")
    voice_input: bool = Field(False, description="Whether to generate voice response")
    tools_to_use: Optional[List[str]] = Field(None, description="Specific tools to use")
    stream: bool = Field(False, description="Whether to stream the response")


class ToolCall(BaseModel):
    """Tool call made during response generation."""
    name: str
    arguments: Dict[str, Any]
    result: Optional[str] = None


class PaperReference(BaseModel):
    """Paper reference in response."""
    title: str
    authors: List[str]
    arxiv_id: Optional[str] = None
    url: Optional[str] = None
    published: Optional[str] = None


class ChatResponse(BaseModel):
    """Response from chat completion."""
    response: str
    session_id: str
    tool_calls: List[ToolCall] = []
    papers: List[PaperReference] = []
    audio_url: Optional[str] = None
    timestamp: datetime = Field(default_factory=datetime.utcnow)


# ============ Transcription Models ============

class TranscriptionRequest(BaseModel):
    """Request for audio transcription."""
    language: Optional[str] = Field(None, description="Language code (auto-detect if None)")


class TranscriptionResponse(BaseModel):
    """Response from audio transcription."""
    text: str
    language: str
    confidence: float = 1.0
    duration: Optional[float] = None
    model: str = ""


# ============ TTS Models ============

class TTSRequest(BaseModel):
    """Request for text-to-speech."""
    text: str = Field(..., description="Text to synthesize")
    voice: Optional[str] = Field(None, description="Voice to use (default from config)")


class TTSResponse(BaseModel):
    """Response from text-to-speech."""
    audio_url: str
    text: str
    engine: str
    voice: str
    duration: Optional[float] = None


# ============ Session Models ============

class CreateSessionRequest(BaseModel):
    """Request to create a new session."""
    title: Optional[str] = None
    metadata: Optional[Dict[str, Any]] = None


class SessionMessage(BaseModel):
    """Message in session history."""
    role: str
    content: str
    timestamp: Optional[datetime] = None


class SessionResponse(BaseModel):
    """Session information."""
    session_id: str
    title: Optional[str] = None
    created_at: datetime
    updated_at: datetime
    messages: List[SessionMessage] = []
    message_count: int = 0
    metadata: Optional[Dict[str, Any]] = None


class SessionListResponse(BaseModel):
    """List of sessions."""
    sessions: List[SessionResponse]
    total: int


# ============ Tool Models ============

class ArxivSearchRequest(BaseModel):
    """Request for ArXiv search."""
    query: str = Field(..., description="Search query")
    category: Optional[str] = Field("", description="ArXiv category")
    max_results: int = Field(10, ge=1, le=20, description="Max results")
    sort_by: str = Field("relevance", description="Sort order")


class WebSearchRequest(BaseModel):
    """Request for web search."""
    query: str = Field(..., description="Search query")
    max_results: int = Field(5, ge=1, le=10, description="Max results")
    search_depth: str = Field("basic", description="Search depth")


class SummarizeRequest(BaseModel):
    """Request to summarize papers."""
    papers: List[Dict[str, Any]] = Field(..., description="Papers to summarize")
    focus: Optional[str] = Field(None, description="Focus area")
    detail_level: str = Field("moderate", description="Detail level")
    compare: bool = Field(False, description="Compare multiple papers")


# ============ Vector Store Models ============

class VectorSearchRequest(BaseModel):
    """Request for vector search."""
    query: str = Field(..., description="Search query")
    n_results: int = Field(5, ge=1, le=20, description="Number of results")


class VectorSearchResponse(BaseModel):
    """Response from vector search."""
    results: List[Dict[str, Any]]
    query: str
    count: int


class IndexPapersRequest(BaseModel):
    """Request to index papers into vector store."""
    rag_data_path: str = Field(..., description="Path to RAG JSON file")


# ============ Health & Status Models ============

class HealthResponse(BaseModel):
    """Health check response."""
    status: str
    version: str
    services: Dict[str, bool]


class ServiceStatus(BaseModel):
    """Status of individual services."""
    name: str
    available: bool
    details: Optional[str] = None


class StatusResponse(BaseModel):
    """Overall system status."""
    services: List[ServiceStatus]
    vector_store_stats: Optional[Dict[str, Any]] = None
    session_count: int = 0


# ============ Error Models ============

class ErrorResponse(BaseModel):
    """Error response."""
    error: str
    detail: Optional[str] = None
    code: Optional[str] = None

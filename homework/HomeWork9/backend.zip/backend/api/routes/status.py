"""Status route for system health checks."""
from backend.api.models import StatusResponse, ServiceStatus
from backend.core.config import settings
from backend.services.vector_store import get_vector_store
from backend.core.session_manager import get_session_manager


async def get_system_status() -> StatusResponse:
    """Get comprehensive system status."""
    services = []

    # Check ASR
    try:
        from backend.services.asr import get_asr_service
        asr = get_asr_service()
        services.append(ServiceStatus(
            name="asr",
            available=True,
            details=f"Whisper model: {asr.model_size}"
        ))
    except Exception as e:
        services.append(ServiceStatus(
            name="asr",
            available=False,
            details=str(e)
        ))

    # Check TTS
    try:
        from backend.services.tts import get_tts_service
        tts = get_tts_service()
        services.append(ServiceStatus(
            name="tts",
            available=True,
            details=f"Engine: {tts.engine_name}"
        ))
    except Exception as e:
        services.append(ServiceStatus(
            name="tts",
            available=False,
            details=str(e)
        ))

    # Check LLM
    services.append(ServiceStatus(
        name="llm",
        available=bool(settings.OPENAI_API_KEY),
        details=f"Model: {settings.OPENAI_MODEL}" if settings.OPENAI_API_KEY else "No API key"
    ))

    # Check Notion
    services.append(ServiceStatus(
        name="notion",
        available=settings.ENABLE_NOTION_SYNC and bool(settings.NOTION_API_KEY),
        details="Enabled" if settings.ENABLE_NOTION_SYNC else "Disabled"
    ))

    # Check Vector DB
    vector_store_stats = None
    session_count = 0

    if settings.ENABLE_VECTOR_SEARCH:
        try:
            vs = get_vector_store()
            vector_store_stats = vs.get_stats()
            services.append(ServiceStatus(
                name="vector_db",
                available=True,
                details=f"Documents: {vector_store_stats.get('document_count', 0)}"
            ))
        except Exception as e:
            services.append(ServiceStatus(
                name="vector_db",
                available=False,
                details=str(e)
            ))

    # Check sessions
    try:
        sm = get_session_manager()
        all_sessions = sm.list_sessions()
        session_count = len(all_sessions)
        services.append(ServiceStatus(
            name="sessions",
            available=True,
            details=f"Active sessions: {session_count}"
        ))
    except Exception as e:
        services.append(ServiceStatus(
            name="sessions",
            available=False,
            details=str(e)
        ))

    return StatusResponse(
        services=services,
        vector_store_stats=vector_store_stats,
        session_count=session_count
    )

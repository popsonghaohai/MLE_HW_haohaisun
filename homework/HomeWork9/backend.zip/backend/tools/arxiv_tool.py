"""
ArXiv Search Tool - Search and retrieve academic papers from arXiv.
"""
import logging
import asyncio
from typing import Optional, List, Dict, Any
import feedparser
import arxiv

from .base import BaseTool, ToolResult

logger = logging.getLogger(__name__)


class ArxivTool(BaseTool):
    """
    Tool for searching and retrieving papers from arXiv.
    """

    name = "search_arxiv"
    description = """Search academic papers on arXiv across various fields including Computer Science, Mathematics, Physics, and more.
Use this tool when the user asks about academic research, papers, or specific research topics."""

    def __init__(self, max_results: int = 10):
        """
        Initialize the ArXiv tool.

        Args:
            max_results: Maximum number of results to return
        """
        self.max_results = max_results
        self.client = arxiv.Client(
            page_size=100,
            delay_seconds=3.0,
            num_retries=3
        )

    def get_parameters_schema(self) -> Dict:
        return {
            "type": "object",
            "properties": {
                "query": {
                    "type": "string",
                    "description": "Search query for arXiv papers (e.g., 'machine learning transformers')"
                },
                "category": {
                    "type": "string",
                    "description": "ArXiv category to filter by (e.g., cs.AI, cs.CL, math.NA). Leave empty for all categories.",
                    "default": ""
                },
                "max_results": {
                    "type": "integer",
                    "description": "Maximum number of results to return (1-20)",
                    "default": 10,
                    "minimum": 1,
                    "maximum": 20
                },
                "sort_by": {
                    "type": "string",
                    "description": "Sort order for results",
                    "enum": ["relevance", "lastUpdatedDate", "submittedDate"],
                    "default": "relevance"
                }
            },
            "required": ["query"]
        }

    async def execute(
        self,
        query: str,
        category: str = "",
        max_results: Optional[int] = None,
        sort_by: str = "relevance"
    ) -> ToolResult:
        """
        Execute ArXiv search.

        Args:
            query: Search query
            category: Optional category filter
            max_results: Max results (uses instance default if None)
            sort_by: Sort order

        Returns:
            ToolResult with paper list
        """
        max_results = max_results or self.max_results

        try:
            # Build search query
            search_query = f"all:{query}"
            if category:
                search_query = f"cat:{category} AND all:{query}"

            logger.info(f"ArXiv search: query='{query}', category='{category}', max_results={max_results}")

            # Create search
            sort = arxiv.SortCriterion.Relevance
            if sort_by == "lastUpdatedDate":
                sort = arxiv.SortCriterion.LastUpdatedDate
            elif sort_by == "submittedDate":
                sort = arxiv.SortCriterion.SubmittedDate

            search = arxiv.Search(
                query=search_query,
                max_results=max_results,
                sort_by=sort
            )

            # Execute search
            results = []
            async for result in self._async_search(search):
                results.append(self._format_result(result))

            logger.info(f"ArXiv search returned {len(results)} papers")

            return ToolResult(
                success=True,
                data=results,
                metadata={"count": len(results), "query": query}
            )

        except Exception as e:
            logger.error(f"ArXiv search error: {e}")
            return ToolResult(
                success=False,
                error=str(e)
            )

    async def _async_search(self, search: arxiv.Search):
        """Async wrapper for arXiv search."""
        loop = asyncio.get_event_loop()
        results = []

        def sync_search():
            for result in self.client.results(search):
                results.append(result)

        await loop.run_in_executor(None, sync_search)

        for result in results:
            yield result

    def _format_result(self, result: arxiv.Result) -> Dict[str, Any]:
        """Format an arXiv result into a dictionary."""
        return {
            "title": result.title,
            "authors": [author.name for author in result.authors],
            "summary": result.summary.replace("\n", " "),
            "published": result.published.strftime("%Y-%m-%d") if result.published else "",
            "updated": result.updated.strftime("%Y-%m-%d") if result.updated else "",
            "arxiv_id": result.entry_id.split("/")[-1],
            "url": result.entry_id,
            "pdf_url": result.pdf_url,
            "primary_category": result.primary_category,
            "categories": result.categories,
            "doi": result.doi,
            "comment": result.comment
        }

    async def get_paper_abstract(self, arxiv_id: str) -> ToolResult:
        """
        Get the abstract for a specific paper.

        Args:
            arxiv_id: ArXiv paper ID (e.g., "2301.00001")

        Returns:
            ToolResult with paper details
        """
        try:
            search = arxiv.Search(id_list=[arxiv_id])
            result = next(self.client.results(search), None)

            if not result:
                return ToolResult(
                    success=False,
                    error=f"Paper not found: {arxiv_id}"
                )

            return ToolResult(
                success=True,
                data=self._format_result(result)
            )

        except Exception as e:
            return ToolResult(
                success=False,
                error=str(e)
            )


# Convenience function for direct usage
async def search_arxiv(
    query: str,
    category: str = "",
    max_results: int = 10,
    sort_by: str = "relevance",
    index_to_vector_store: bool = True
) -> str:
    """
    Search arXiv and return formatted results.

    Args:
        query: Search query
        category: Optional category filter
        max_results: Maximum results
        sort_by: Sort order
        index_to_vector_store: Whether to index papers to vector store for RAG

    Returns:
        Formatted string with results
    """
    tool = ArxivTool()
    result = await tool.execute(
        query=query,
        category=category,
        max_results=max_results,
        sort_by=sort_by
    )

    if not result.success:
        return f"Error searching ArXiv: {result.error}"

    papers = result.data
    if not papers:
        return "No papers found matching your query."

    # Index papers to vector store for RAG if enabled
    if index_to_vector_store:
        try:
            from backend.services.vector_store import get_vector_store
            from backend.core.config import settings

            if settings.ENABLE_VECTOR_SEARCH:
                vector_store = get_vector_store()
                indexed_count = 0
                for paper in papers:
                    # Prepare paper data for indexing
                    paper_data = {
                        "title": paper.get("title", ""),
                        "arxiv_id": paper.get("arxiv_id", ""),
                        "authors": paper.get("authors", []),
                        "summary": paper.get("summary", ""),
                        "abstract": paper.get("summary", ""),  # Use summary as abstract
                        "url": paper.get("url", ""),
                        "pdf_url": paper.get("pdf_url", ""),
                        "published": paper.get("published", ""),
                        "primary_category": paper.get("primary_category", ""),
                        "categories": paper.get("categories", []),
                        "full_text": f"{paper.get('title', '')}\n\nAbstract: {paper.get('summary', '')}"
                    }
                    chunks = vector_store.add_paper_chunks(paper_data)
                    if chunks > 0:
                        indexed_count += 1

                if indexed_count > 0:
                    logger.info(f"Indexed {indexed_count} papers to vector store for RAG")
        except Exception as e:
            logger.warning(f"Failed to index papers to vector store: {e}")

    output = [f"Found {len(papers)} papers:\n"]

    for i, paper in enumerate(papers, 1):
        output.append(f"\n{i}. **{paper['title']}**")
        output.append(f"   Authors: {', '.join(paper['authors'][:3])}")
        if len(paper['authors']) > 3:
            output.append(f"   et al.")
        output.append(f"   Published: {paper['published']}")
        output.append(f"   ArXiv ID: {paper['arxiv_id']}")
        output.append(f"   URL: {paper['url']}")
        output.append(f"   Abstract: {paper['summary'][:300]}...")

    return "\n".join(output)

"""
Summarization Tool - Synthesize and summarize research papers and findings.
"""
import logging
from typing import Optional, List, Dict, Any
from dataclasses import dataclass

from .base import BaseTool, ToolResult
from openai import AsyncOpenAI

logger = logging.getLogger(__name__)


@dataclass
class PaperSummary:
    """Container for a paper summary."""
    title: str
    authors: List[str]
    year: str
    key_contributions: List[str]
    methodology: str
    findings: str
    limitations: Optional[str] = None
    arxiv_id: Optional[str] = None


class SummarizerTool(BaseTool):
    """
    Tool for summarizing research papers and synthesizing multiple papers.
    Uses GPT-4 for intelligent summarization with citation preservation.
    """

    name = "summarize_papers"
    description = """Summarize and synthesize research papers. Can summarize individual papers or compare multiple papers on a topic.
Use this tool when the user wants to understand the key contributions, methodology, and findings of research papers,
or wants a comparison of multiple papers."""

    def __init__(self, api_key: str, model: str = "gpt-4o"):
        """
        Initialize the summarizer.

        Args:
            api_key: OpenAI API key
            model: Model to use for summarization
        """
        self.client = AsyncOpenAI(api_key=api_key)
        self.model = model

    def get_parameters_schema(self) -> Dict:
        return {
            "type": "object",
            "properties": {
                "papers": {
                    "type": "array",
                    "items": {"type": "object"},
                    "description": "List of papers to summarize. Each paper should have title, authors, summary/abstract content."
                },
                "focus": {
                    "type": "string",
                    "description": "Optional aspect to focus on (e.g., 'methodology', 'results', 'contributions')"
                },
                "detail_level": {
                    "type": "string",
                    "description": "Level of detail in summary",
                    "enum": ["brief", "moderate", "detailed"],
                    "default": "moderate"
                },
                "compare": {
                    "type": "boolean",
                    "description": "If True with multiple papers, provide a comparison/synthesis",
                    "default": False
                }
            },
            "required": ["papers"]
        }

    async def execute(
        self,
        papers: List[Dict[str, Any]],
        focus: Optional[str] = None,
        detail_level: str = "moderate",
        compare: bool = False
    ) -> ToolResult:
        """
        Execute paper summarization.

        Args:
            papers: List of papers to summarize
            focus: Optional focus area
            detail_level: Level of detail
            compare: Whether to compare multiple papers

        Returns:
            ToolResult with summary
        """
        if not papers:
            return ToolResult(
                success=False,
                error="No papers provided for summarization"
            )

        try:
            if len(papers) == 1:
                summary = await self._summarize_single(papers[0], focus, detail_level)
            else:
                summary = await self._summarize_multiple(papers, focus, detail_level, compare)

            return ToolResult(
                success=True,
                data=summary,
                metadata={"paper_count": len(papers)}
            )

        except Exception as e:
            logger.error(f"Summarization error: {e}")
            return ToolResult(
                success=False,
                error=str(e)
            )

    async def _summarize_single(
        self,
        paper: Dict[str, Any],
        focus: Optional[str],
        detail_level: str
    ) -> str:
        """Summarize a single paper."""
        prompt = self._build_single_paper_prompt(paper, focus, detail_level)

        response = await self.client.chat.completions.create(
            model=self.model,
            messages=[{"role": "user", "content": prompt}],
            temperature=0.3,
            max_tokens=1500
        )

        return response.choices[0].message.content

    async def _summarize_multiple(
        self,
        papers: List[Dict[str, Any]],
        focus: Optional[str],
        detail_level: str,
        compare: bool
    ) -> str:
        """Summarize multiple papers."""
        prompt = self._build_multiple_papers_prompt(papers, focus, detail_level, compare)

        response = await self.client.chat.completions.create(
            model=self.model,
            messages=[{"role": "user", "content": prompt}],
            temperature=0.4,
            max_tokens=2000
        )

        return response.choices[0].message.content

    def _build_single_paper_prompt(
        self,
        paper: Dict[str, Any],
        focus: Optional[str],
        detail_level: str
    ) -> str:
        """Build prompt for single paper summarization."""
        detail_instructions = {
            "brief": "Provide a concise 2-3 sentence summary",
            "moderate": "Provide a comprehensive summary in 3-5 paragraphs",
            "detailed": "Provide an extensive summary covering all aspects in detail"
        }

        prompt = f"""Please summarize the following research paper.

**Paper:**
- Title: {paper.get('title', 'Unknown')}
- Authors: {', '.join(paper.get('authors', []))}

**Abstract/Content:**
{paper.get('summary', paper.get('abstract', paper.get('content', '')))[:3000]}

{detail_instructions.get(detail_level, detail_instructions['moderate'])}.
"""

        if focus:
            prompt += f"\n\nFocus particularly on: {focus}"

        prompt += """

Please structure your summary to include:
1. **Key Contributions**: What are the main contributions of this work?
2. **Methodology**: What approach or methods were used?
3. **Key Findings**: What were the main results or findings?
4. **Significance**: Why is this work important or novel?"""

        return prompt

    def _build_multiple_papers_prompt(
        self,
        papers: List[Dict[str, Any]],
        focus: Optional[str],
        detail_level: str,
        compare: bool
    ) -> str:
        """Build prompt for multiple paper summarization."""
        papers_text = ""
        for i, paper in enumerate(papers, 1):
            papers_text += f"""
**Paper {i}:**
- Title: {paper.get('title', 'Unknown')}
- Authors: {', '.join(paper.get('authors', []))}
- Abstract: {paper.get('summary', paper.get('abstract', ''))[:1500]}
"""

        if compare:
            instruction = """Compare and synthesize these papers. Provide:
1. A brief summary of each paper
2. Common themes and approaches
3. Key differences between the papers
4. How they complement or contrast with each other
5. Overall state of research in this area based on these papers"""
        else:
            instruction = f"""Summarize each of these papers separately, then provide a synthesis of the overall research landscape."""

        prompt = f"""Please analyze the following research papers.

{papers_text}

{instruction}
"""

        if focus:
            prompt += f"\n\nFocus particularly on: {focus}"

        return prompt

    async def extract_key_points(
        self,
        text: str,
        num_points: int = 5
    ) -> List[str]:
        """
        Extract key points from a text.

        Args:
            text: Text to extract from
            num_points: Number of key points to extract

        Returns:
            List of key points
        """
        prompt = f"""Extract the {num_points} most important points from the following text.

Text:
{text[:3000]}

Return only the key points as a numbered list."""

        response = await self.client.chat.completions.create(
            model=self.model,
            messages=[{"role": "user", "content": prompt}],
            temperature=0.3,
            max_tokens=500
        )

        content = response.choices[0].message.content

        # Parse numbered list
        points = []
        for line in content.split('\n'):
            line = line.strip()
            if line and (line[0].isdigit() or line.startswith('-')):
                points.append(line)

        return points[:num_points]


# Convenience function for direct usage
async def summarize_papers(
    papers: List[Dict[str, Any]],
    focus: Optional[str] = None,
    compare: bool = False
) -> str:
    """
    Summarize research papers.

    Args:
        papers: List of papers to summarize
        focus: Optional focus area
        compare: Whether to compare multiple papers

    Returns:
        Summary text
    """
    from backend.core.config import settings

    tool = SummarizerTool(
        api_key=settings.OPENAI_API_KEY,
        model=settings.OPENAI_MODEL
    )

    result = await tool.execute(
        papers=papers,
        focus=focus,
        compare=compare
    )

    if not result.success:
        return f"Error summarizing papers: {result.error}"

    return result.data

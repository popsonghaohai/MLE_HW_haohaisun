"""
Base classes for tools in the Academic Research Assistant.
"""
from abc import ABC, abstractmethod
from typing import Any, Dict, Optional
from dataclasses import dataclass, field


@dataclass
class ToolResult:
    """Standard result object for all tools."""
    success: bool
    data: Any = None
    error: Optional[str] = None
    metadata: Dict = field(default_factory=dict)

    def to_dict(self) -> Dict:
        """Convert to dictionary."""
        return {
            "success": self.success,
            "data": self.data,
            "error": self.error,
            "metadata": self.metadata
        }

    def to_message_content(self) -> str:
        """Convert to message content for LLM."""
        if self.success:
            if isinstance(self.data, str):
                return self.data
            elif isinstance(self.data, dict):
                import json
                return json.dumps(self.data, ensure_ascii=False, indent=2)
            elif isinstance(self.data, list):
                import json
                return json.dumps(self.data, ensure_ascii=False, indent=2)
            else:
                return str(self.data)
        else:
            return f"Error: {self.error}"


class BaseTool(ABC):
    """Abstract base class for all tools."""

    name: str = ""
    description: str = ""

    @abstractmethod
    async def execute(self, **kwargs) -> ToolResult:
        """Execute the tool with given parameters."""
        pass

    def get_parameters_schema(self) -> Dict:
        """Return the JSON schema for tool parameters."""
        return {
            "type": "object",
            "properties": {},
            "required": []
        }

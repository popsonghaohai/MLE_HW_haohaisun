"""
Web Search Tool - Search the web for academic information.
Uses Tavily API for academic-focused web search.
"""
import logging
import os
from typing import Optional, List, Dict, Any
from dataclasses import dataclass

from .base import BaseTool, ToolResult

logger = logging.getLogger(__name__)

try:
    from tavily import TavilyClient
    TAVILY_AVAILABLE = True
except ImportError:
    TAVILY_AVAILABLE = False


@dataclass
class SearchResult:
    """Individual web search result."""
    title: str
    url: str
    content: str
    score: float = 0.0
    published_date: Optional[str] = None


class WebSearchTool(BaseTool):
    """
    Tool for web search using Tavily API.
    Optimized for academic and research content.
    """

    name = "search_web"
    description = """Search the web for academic information, research papers, university resources, and general knowledge.
Use this tool when the user asks about topics that may not be on arXiv, needs general background information,
or wants recent news and developments in a field."""

    def __init__(self, api_key: Optional[str] = None, max_results: int = 5):
        """
        Initialize the web search tool.

        Args:
            api_key: Tavily API key (reads from env if None)
            max_results: Maximum number of results
        """
        self.max_results = max_results

        if not TAVILY_AVAILABLE:
            logger.warning("tavily-python not installed. Web search will be unavailable.")

        self.api_key = api_key or os.getenv("TAVILY_API_KEY", "")
        self.client = None

        if self.api_key and TAVILY_AVAILABLE:
            self.client = TavilyClient(api_key=self.api_key)
            logger.info("Tavily client initialized")
        else:
            logger.warning("Tavily client not available - missing API key")

    def get_parameters_schema(self) -> Dict:
        return {
            "type": "object",
            "properties": {
                "query": {
                    "type": "string",
                    "description": "Search query for web search"
                },
                "max_results": {
                    "type": "integer",
                    "description": "Maximum number of results (1-10)",
                    "default": 5,
                    "minimum": 1,
                    "maximum": 10
                },
                "search_depth": {
                    "type": "string",
                    "description": "Search depth - 'basic' for faster, 'advanced' for deeper",
                    "enum": ["basic", "advanced"],
                    "default": "basic"
                },
                "include_domains": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "List of domains to prioritize (e.g., ['edu', 'org'])"
                }
            },
            "required": ["query"]
        }

    async def execute(
        self,
        query: str,
        max_results: Optional[int] = None,
        search_depth: str = "basic",
        include_domains: Optional[List[str]] = None
    ) -> ToolResult:
        """
        Execute web search.

        Args:
            query: Search query
            max_results: Maximum results
            search_depth: Search depth level
            include_domains: Domains to include

        Returns:
            ToolResult with search results
        """
        max_results = max_results or self.max_results

        if not self.client:
            return ToolResult(
                success=False,
                error="Tavily client not available. Please set TAVILY_API_KEY."
            )

        try:
            logger.info(f"Web search: query='{query}', max_results={max_results}")

            # Execute search
            response = self.client.search(
                query=query,
                max_results=max_results,
                search_depth=search_depth,
                include_domains=include_domains,
                include_answer=True,
                include_raw_content=False
            )

            # Format results
            results = []
            for answer in response.get("results", []):
                results.append(SearchResult(
                    title=answer.get("title", ""),
                    url=answer.get("url", ""),
                    content=answer.get("content", ""),
                    score=answer.get("score", 0.0),
                    published_date=answer.get("published_date")
                ).__dict__)

            # Add answer if available
            answer_text = response.get("answer", "")

            logger.info(f"Web search returned {len(results)} results")

            return ToolResult(
                success=True,
                data={
                    "answer": answer_text,
                    "results": results,
                    "query": query
                },
                metadata={"count": len(results)}
            )

        except Exception as e:
            logger.error(f"Web search error: {e}")
            return ToolResult(
                success=False,
                error=str(e)
            )

    def _format_result(self, result: SearchResult) -> Dict[str, Any]:
        """Format a search result."""
        return {
            "title": result.title,
            "url": result.url,
            "content": result.content,
            "score": result.score,
            "published_date": result.published_date
        }


# Fallback: Simple requests-based search (for demo without API key)
class FallbackWebSearchTool(BaseTool):
    """Fallback web search using basic requests (limited functionality)."""

    name = "search_web_fallback"
    description = "Fallback web search using DuckDuckGo HTML (no API key required, limited results)."

    async def execute(
        self,
        query: str,
        max_results: int = 5,
        **kwargs
    ) -> ToolResult:
        """Execute fallback web search."""
        import requests
        from bs4 import BeautifulSoup

        try:
            # Use DuckDuckGo HTML version
            url = "https://html.duckduckgo.com/html/"
            params = {"q": query}

            response = requests.post(url, data=params, headers={"User-Agent": "Mozilla/5.0"})
            response.raise_for_status()

            soup = BeautifulSoup(response.text, 'html.parser')

            results = []
            for result in soup.find_all('div', class_='result')[:max_results]:
                title_elem = result.find('a', class_='result__a')
                snippet_elem = result.find('a', class_='result__snippet')

                if title_elem:
                    results.append({
                        "title": title_elem.get_text(),
                        "url": title_elem.get('href', ''),
                        "content": snippet_elem.get_text() if snippet_elem else ''
                    })

            return ToolResult(
                success=True,
                data={"results": results, "query": query},
                metadata={"count": len(results), "source": "duckduckgo"}
            )

        except Exception as e:
            return ToolResult(
                success=False,
                error=f"Fallback search failed: {str(e)}"
            )


# Convenience function for direct usage
async def search_web(
    query: str,
    max_results: int = 5,
    search_depth: str = "basic"
) -> str:
    """
    Search the web and return formatted results.

    Args:
        query: Search query
        max_results: Maximum results
        search_depth: Search depth

    Returns:
        Formatted string with results
    """
    tool = WebSearchTool()
    result = await tool.execute(
        query=query,
        max_results=max_results,
        search_depth=search_depth
    )

    if not result.success:
        # Try fallback
        fallback = FallbackWebSearchTool()
        result = await fallback.execute(query=query, max_results=max_results)

    if not result.success:
        return f"Error searching web: {result.error}"

    data = result.data
    output = []

    if data.get("answer"):
        output.append(f"**Summary:** {data['answer']}\n")

    output.append(f"Found {len(data.get('results', []))} results:\n")

    for i, item in enumerate(data.get("results", []), 1):
        output.append(f"\n{i}. **{item['title']}**")
        output.append(f"   URL: {item['url']}")
        if item.get('content'):
            output.append(f"   {item['content'][:200]}...")

    return "\n".join(output)
